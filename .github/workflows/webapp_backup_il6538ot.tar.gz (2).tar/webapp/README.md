# easyTenancy Global OS · ESTATE OS™ 2026.1 Ganymede

> The **#1 Global Real Estate Operating System** — the intersection of AI, a licensed capital layer, Net-Zero telemetry, and sovereign edge infrastructure. **25 modules · 400+ features · 84 countries · 38 edge PoPs · 12 sovereign clouds · 800+ integrations.**
>
> **v4.10** ships the **Holy Trinity Blueprint** — a monopoly-grade unification of the entire real estate value chain across three architectural layers (Physical / Financial / Operational), with 6 new modules and 3 proprietary protocols (**Proof-of-Physical-Progress · Universal Interop · Cross-Portfolio Zero-Vacancy Router**) that make cloning economically impossible.
>
> **v4.9** shipped **easyTenancy Fleet Core** — real-time Robotics & Spatial Automation Fleet Management for security rovers, care AMRs, elevator delivery bots, and UV-C maintenance drones — with ROS 2 · VDA 5050 · BACnet · MQTT middleware.

## Live URLs

- **Sandbox preview**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai
- **Sandbox — 🆕 v5.0-α · ESTATE OS Control Room**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/estate-os
- **Sandbox — 🆕 v5.0-α · EstateBrain + MCP Terminal**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/ai-core
- **Sandbox — 🆕 v5.0-α · M08 Fintech (Rails · Escrow · Lenders)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/08-fintech
- **Sandbox — 🆕 v5.0-α · M10 Capital Markets (Waterfall · LP Wizard)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/10-capital-markets
- **Sandbox — 🆕 v5.0-α · M19 Asset Management (EstateBrain™ Actions)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/19-asset-management
- **Sandbox — 🆕 v5.0-α · M22 Fractional Ownership (Reg-D/S/A+)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/22-fractional-ownership
- **Sandbox — 🆕 v5.2.3-α · M27 Family Bank (Infinite Banking · Trust Asset Loop)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/27-family-bank
- **Sandbox — 🆕 v5.0-α · M23 Secondary Marketplace (Order Book)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/23-secondary-marketplace
- **Sandbox — 🆕 v5.0-β · M03 Inventory Launch (Wave Pricing · 8 Portals)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/03-inventory-launch
- **Sandbox — 🆕 v5.0-β · M04 CRM & ZK-Identity Vault**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/04-crm-pipeline
- **Sandbox — 🆕 v5.0-β · M05 Deal Room & Conveyancing Copilot**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/05-deal-room
- **Sandbox — 🆕 v5.0-β · M06 Property Ops · IoT & PM (SLA Escrow)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/06-property-ops
- **Sandbox — 🆕 v5.0-β · M12 Brokerage Ops (Roster · Waterfall · T+0)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/12-brokerage
- **Sandbox — 🆕 v5.0-β · M24 Land · BIM · Drone (Milestone Ladder)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/module/24-project-tracker
- **Sandbox — Holy Trinity Hub**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/trinity
- **Sandbox — 🆕 easyConstruct Core**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/construct
- **Sandbox — 🆕 easyMarket Axis**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/market
- **Sandbox — 🆕 easyCapital OS**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/capital
- **Sandbox — 🆕 v5.3.0-α · Internal Sales & Marketing Team Engine**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/sales-engine   (aliases: `/sales` · `/sales-marketing` · `/marketing` · `/growth` · `/crm` · `/team` · `/pipeline`)
- **Sandbox — easyReach (Spatial Web · Demand Matching · Dynamic Yield)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/reach
- **Sandbox — 🆕 easyProject Pro**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/project
- **Sandbox — Fleet Core (Robotics)**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/fleet
- **Sandbox — Global OS 25-Modules map**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/estate-brain
- **Sandbox — App demo**: https://3000-il6538otoxb3se2g4uufh-583b4d74.sandbox.novita.ai/app/demo
- **GitHub (existing)**: https://github.com/smarthomespropertieske-pixel/easy-Tenancy-Global-OS
- **Production (when deployed)**: `easy-tenancy-global-os.pages.dev`

## What's completed

### 🆕 **v5.5.1-alpha M1.4 — PredictiveLifeOS four-mode adaptive Knowledge Graph**

Rewrites the PredictiveLifeOS Knowledge Graph on top of a **container-driven** layout engine, retiring the global `overflow-x: hidden` masking that was hiding real horizontal-overflow bugs. Four adaptive modes share graph data, selection state, interaction model, and accessibility semantics — only presentation depth, geometry, density, and metadata representation adapt.

- **`src/lib/useGraphLayout.ts`** — new hook resolving the section's container width (ResizeObserver + rAF-coalesced updates) to a `GraphLayoutConfig` (mode / size / maxDepth / maxVisibleNodes / labelMode / hitRadius / interaction / layout / metadata). Container thresholds: `mobile < 640`, `compact 640–899`, `desktop 900–1199`, `wide ≥ 1200`. Zero-width guard returns desktop config (avoids first-paint flash). Hit radius is always ≥ 22 CSS-px → 44 px tap diameter.
- **`src/components/MobileFocusExplorer.tsx`** — replaces the shrunken SVG on phones with a `<dl>`-based focus explorer: focus card + first-degree neighbor strip (full-width buttons, `minHeight: 44` px) + ring pager + history back-stack. `data-testid="explorer-neighbors"` for regression tests.
- **`src/lib/v5Interactions.tsx` — RadialKnowledgeGraph** — backward-compatible API extension (7 optional M1.4 props); nodes/edges filtered by `depthAllows(ring)` + `visibleNodeIds.has(id)`; `labelMode` = `off | short | full | on-focus`; SVG changed from `overflow: 'visible'` → `overflow: 'hidden'`; hit radius `Math.max(hitRadiusCssPx ?? nodeR + 8, 22)`.
- **`src/routes/PredictiveLifeOS.tsx`** — KG+Article grid switched to `gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)'`; `S.section`, `S.article`, `S.solutionCard` given `minWidth: 0` and bounded tracks; metadata section now branches `isGraphMobile ? <dl> cards : bounded <table>`.
- **Global `overflow-x: hidden` removed** at 4 sites (`src/index.tsx` body inline CSS, `src/styles/global.css` body + 2 prevent-scroll rules); local scope-only clipping added to the `.trinity-ticker-marquee`/`tickerBar` (decorative only) to prevent legitimate marquee-track overflow leaking to the page.

**Test coverage:**
- `tests/unit/useGraphLayout.spec.ts` — 48 unit tests (mode picking, per-mode invariants, universal invariants — hit radius ≥ 22, size > 0, zero-width guard)
- `tests/e2e/predictive-os-kg-modes.spec.ts` — 32 usability regressions against 6 contractual viewports (375 / 430 / 768 / 1024 / 1280 / 1440):
  - No body-level horizontal overflow at any viewport
  - Container-driven `data-kg-mode` matches the container-width threshold at every viewport
  - Grid track never exceeds its container
  - Phones: `<dl>` explorer present, radial SVG absent, metadata cards present, metadata table absent
  - Phones: every neighbor and card CTA button has ≥ 44 CSS-px height
  - Compact/desktop/wide: radial SVG present and bounded, aspect-ratio preserved
  - Compact/desktop/wide: bounded metadata table with `overflow-x: auto`, 9 header columns, `<dl>` cards absent
  - Wide-mode split layout uses two `minmax(0, 1fr)` tracks
- `tests/e2e/predictive-os-responsive.spec.ts` — M1.3 baseline restated (10 tests, all still green under M1.4)

### **v5.5.0-alpha — Living Canonical Entity Engine (Estate OS 5-Layer Refactor)**

Refactored Estate OS from page-based encyclopedia rendering to a **Living Canonical Entity System** organised as 5 layers of a persistent property nervous system. Every entity (property, organization, market, protocol) is now first-class: it owns a canonical URL, a 5-tab workspace, telemetry state, intelligence, executable actions, and an opportunity radar.

- **New canonical routes** — every entity gets its own persistent workspace with URL-scrubbed state
  - `/property/:id?view=<encyclopedia|control|operations|graph|timeline>&t=<live|30d|90d|1y>&asset=<iotId>&cite=<n>`
  - `/organization/:id` — registry stub (owner / manager / bank)
  - `/market/:id` — registry stub (submarket lens)
  - `/protocol/:id` — registry stub (EVM / ISO / regulatory scheme)
  - Registry aliases honoured: `/property/DE-BER-091` resolves to `PROP-BER-001`
- **5-Layer architecture**
  - **L1 Knowledge** — canonical entity registry (`entities.ts` extended with `SlaCovenant` × 12 and `WorkOrder` × 7)
  - **L2 State** — M06 telemetry live-scoring (`ENC_SLA` 5-state envelope: nominal / watch / warn / breach / critical)
  - **L3 Intelligence** — EstateBrain counterfactual sliders (v5.4.1) + SLA tolerance-band sliders in the Evidence Drawer
  - **L4 Action** — `ActionCenterDrawer` with 5 seed workflows (dispatchTechnician · renewLease · reviewRefinance · retrofitPlan · custom), vertical stepper
  - **L5 Opportunity** — `OpportunityRadar` with 3 deterministic engines: NOI Uplift · Refi Savings · Retrofit ROI
- **5-tab workspace shell** (`EntityRoute.tsx`) — `📖 Encyclopedia · 🎛 Control Room · 🔧 Operations M06 · 🕸 Digital Twin · ⌛ Timeline`; sticky pill-row sub-nav; URL-persisted view + temporal scrubber; deep-link params (`view`, `t`, `asset`, `cite`) survive tab switches and reloads
- **Universal entity anchor** (`EntityLink.tsx`) — canonical anchor with `canonicalRouteFor()` mapping + 280 ms delayed hover-card portal; non-canonical kinds (lease, tenant, tx, IoT, WO, SLA) fall through to `onPeek`; ready for the 40+ callsite migration (deferred to v5.5.1)
- **Graph View — SLA-stress edges + Work-Order ring** — animated dashed bezier paths for warn/breach/critical IoT nodes (control-point offset `bow` = 22 / 36 / 48), new outer Work-Order ring at r=340 with dashed orange edges to origin assets, colours sourced from `ENC_SLA[state].haloRgb` + `ENC_WORKORDER_KIND[kind]`
- **Timeline View — Operations events** — merges Work-Order + `SLA-WARN` + `SLA-BREACH` alongside financial events, filter chips (`ALL / FINANCE / OPERATIONS`), range clamped **2011 → 2030**, breach rows tinted rose-50
- **Evidence Drawer — SLA Tolerance Envelope** — for `kind: 'sensor'` citations, renders a per-covenant ±40 % threshold slider that live-recomputes `slaStateFor()` against the current reading, previews the resulting SLA badge, and warns when the adjusted envelope would trigger the breach policy
- **Entity Peek Drawer — new kind bodies** — `workOrder` (kind + priority + status + SLA + downtime + assignee + covenant) and `slaCovenant` (metric + operator + threshold + reading + state badge + policy + asset link)
- **Control Room View** — Asset Health hero (100 – covenant/work-order/sensor penalties · exemplary ≥90 · healthy ≥75 · attention ≥55 · critical <55) · KPI grid · Executive Position (aiCall + top counterfactual) · live SLA banner · Quick Actions · embedded OpportunityRadar · cross-view jump footer
- **Legacy shell integration** — `EstateOSEncyclopedia.tsx` now injects `ENC_M06_GLOBAL_CSS` (halos + edge dash-flow) and parses `?entity=<registryId>&view=<sla|graph|timeline>&cite=<n>` on mount; Infobox module chips now build canonical M06 deep-links via `buildModuleLink(m.route, { entity, view })`
- **Design tokens** — `ENC_M06_GLOBAL_CSS`, `ENC_SLA`, `ENC_WORKORDER_KIND`, `slaBadgeStyle()`, `workOrderKindBadgeStyle()`, `slaStateFor()`, `buildModuleLink()`, `parseModuleLink()`, `ModuleLinkParams`

**Bundle** — well under the 45 kB gzip cap:
- `EntityRoute-*.js` **38.30 kB** (**11.22 kB gzip**) — v5.5.0 canonical workspace shell
- `EstateOSEncyclopedia-*.js` **12.15 kB** (**4.35 kB gzip**) — thinner legacy shell (chunks below now lazy-load)
- **Combined 15.57 kB gzip** — 3× under budget

**Verification**: `npx tsc --noEmit` → 0 errors · `npm run build` → clean 2 m 39 s · 6-route curl smoke (`/`, `/estate-os`, `/estate-os-encyclopedia`, `/property/PROP-BER-001`, `/control-room`, `/ai-core`) → all 200 · 4-route v5.5.0 canonical smoke (`/property/{PROP-BER-001,DE-BER-091}`, `/organization/OWN-BLK-001`, `/market/DE-BER`, `/protocol/EVM-ERC1400`) → all 200 · chunk fetches (`EntityRoute-*.js`, `EstateOSEncyclopedia-*.js`) → 200

**Deferred to v5.5.1** — 40+ callsite migration to `<EntityLink>` component (mechanical); explicit user decision.

---

### 🆕 **v5.4.1-alpha — ESTATE OS™ Encyclopedia (Knowledge-First OS) · Enterprise Design System + Mobile-First Shell**

The former `/estate-os` Control Room has been transitioned to a canonical **Knowledge-First Operating System** modelled on **Wikipedia × Bloomberg Terminal × Institutional Property Registry × AI Knowledge Graph**. The legacy Control Room dashboard is preserved at `/control-room` (zero regression on existing flows).

- **Routes**
  - `/estate-os` → **Encyclopedia** (remapped)
  - `/estate-os-encyclopedia` → **Encyclopedia** (explicit alias)
  - `/control-room` → legacy Control Room (preserved as reference implementation)
- **3-Layer Concept**
  - **L1 — Knowledge Entities**: `Property · Owner · Lease · Tenant · Transaction · Market · ESG · IoT` (typed union, cross-linked by string IDs)
  - **L2 — 25 OS Modules**: contextual **lenses** over entities (not isolated dashboards)
  - **L3 — Operational Execution**: ⌘K palette · Evidence Drawer · Counterfactual Engine · Entity Peek
- **Views** — Article (default) · Graph (pure-SVG concentric-ring node-link) · Timeline (event-sourced ledger)
- **Temporal Scrubber** — `LIVE · 30D · 90D · 1Y` with a pulsing halo dot on LIVE; every important metric is a `TemporalMetric` object that re-renders synchronously across article body + infobox on scrub
- **Provenance** — `Citation` records with `source · SHA-256 hash · confidence · timestamp · kind · excerpt`; every article `[n]` marker opens the **Evidence Drawer** with Source · Excerpt · Lineage · **Challenge AI Conclusion** counterfactual sliders that flip the AI verdict when thresholds are crossed
- **Command Palette (⌘K / `/`)** — blends entity search (Properties · Owners · Tenants · Markets · IoT) with 25-module routing
- **Enterprise design system (`src/lib/encyclopedia/tokens.ts`)** — self-contained, quarantined from legacy glassmorphic tokens:
  - `ENC_BP` + `ENC_MEDIA` — 6 breakpoints (xs / sm / md / lg / xl / xxl) + media-query helpers (`mobile`, `tablet`, `desktop`, `hover`, `touch`, `reduced`, `dark`, `print`)
  - `ENC_MOTION` — 7 duration tokens (`instant` → `cinema`) + 6 easing curves (`standard`, `decelerate`, `accelerate`, `spring`, `springSoft`, `linear`) + `encTransition()` composer
  - `ENC_Z` — z-index registry (base → toast), single source of truth
  - `ENC_ELEVATION` — 6-tier shadow stack + focus-ring & glow
  - `ENC_GRADIENT` — paper, glass, accent-bar, live-halo, skeleton-shimmer, AI-inference
  - `ENC_FOCUS` — WCAG 2.2 focus-visible ring (keyboard-only)
  - `ENC_TOUCH` — 44 px min tap target (WCAG 2.5.5 / Apple HIG)
  - `ENC_SAFE` — iOS-notch / Android-gesture-bar safe-area inset shortcuts
  - `ENC_GLOBAL_CSS` — one-shot injected keyframes library (`enc-pulse`, `enc-live-halo`, `enc-fade-in`, `enc-fade-in-up/down`, `enc-slide-in-right/-bottom`, `enc-pop-in`, `enc-shimmer`, `enc-metric-flip`), reduced-motion honouring, print reset, thinner mobile scrollbars, momentum touch scrolling
- **Mobile-first shell** (`src/lib/encyclopedia/useViewport.ts` — SSR-safe, rAF-throttled, `prefers-reduced-motion` aware)
  - Desktop (≥ lg): 3-col grid `TOC · Article · Infobox`
  - Tablet (≥ md, < lg): 2-col `Article · Infobox`, TOC via bottom-sheet
  - Mobile (< md): 1-col article, sticky **FAB cluster** (Contents · Info · ⌘K) with safe-area inset, TOC + Infobox both open as bottom-sheets with grabber + backdrop blur
- **Motion** — reading-progress bar at viewport top, sticky glass-blur `TopBar` + `Breadcrumb`, animated view-mode transitions, per-section IntersectionObserver reveal (fade + lift), animated metric flip on temporal scrub, spring bottom-sheets on mobile, pulse + halo LIVE dot, hover-lift on citations and entity links
- **8 cross-linked properties** across 5 jurisdictions (Berlin ×2 · London ×2 · Dubai · Singapore ×2 · Miami) with 13 citations, 8 owners, 8 tenants, 9 leases, 10 transactions, 5 markets, 8 ESG records, 6 IoT assets

**Bundle**: `EstateOSEncyclopedia-*.js` **110.94 kB** (**29.08 kB gzip**) — the entire Knowledge-First OS shell, incl. animation library, mobile-first shell, all 8 sub-components, and the full 8-property universe.

**Verification**: `npx tsc --noEmit` → 0 errors · `npm run build` → clean 7.71 s · `curl` smoke — `/`, `/estate-os`, `/estate-os-encyclopedia`, `/control-room`, `/ai-core`, `/realestate-os` → all 200 · Playwright console capture → 0 errors, URL sync working (`?p=PROP-BER-001` auto-appended).

---

### 🆕 **v5.0.0-alpha — ESTATE OS™ Transaction Layer + Capital Layer Module Suite (Path 3a)**

**Zero-drift additive release** — no rename of the `IP` icon-prop type, no parallel token files. Everything imports from the canonical v5.0 paths (`../lib/trinityTokens`, `../lib/icons/glyphs`, `../lib/icons/Sv`).

**New foundations** (touch-once, reused everywhere):
- ✅ **`src/lib/trinityTokens.ts`** — extended with v5.0 additive tokens (`TC.indigo`, `emeraldV5`, `amberV5`, `violetV5`, `cyanV5`, `rose`, `textV5Primary/Secondary/Muted/Highlight`, `borderGlass/borderIndigo/borderEmerald/borderAmber`, `bgBase/bgCard/bgGlass`), the `V5FX` FX helper (transitions · mono font · tabular nums · glass shadow · indigo glow), plus `glassCardStyle` and `glassCardAccent(accent, glow?)` pre-composed card helpers
- ✅ **`src/lib/icons/Sv.tsx`** — shared multi-path SVG primitive with pipe-split `d` prop and preserved `IP` interface (v4.12)
- ✅ **`src/lib/icons/glyphs.tsx`** — 24 named glyphs incl. `SvShieldCheck · SvCpu · SvBuilding · SvLayers · SvLock · SvCoins · SvScale · SvSparkles · SvWorkflow · SvActivity · SvBrain · SvBolt · SvGavel · SvHouse · SvArrowUpRight · SvTerminal`
- ✅ **`src/lib/estateOsData.ts`** — 8 `MODULE_TILES` · 10-event `ACTIVITY_STREAM` · 6 `CONTROL_ROOM_KPIS` · 6 `MCP_TOOL_TRACES` · 4 `EMBED_CHANS` · `computeEstateOsKPIs()`
- ✅ **`src/lib/analytics.ts`** — 17 new `EventName` entries for `module08_*/module10_*/module19_*/module22_*/module23_*` (view · rail_switched · escrow_disbursed · lender_check · waterfall_adjusted · lp_step_advanced · property_selected · action_ack · framework_toggled · dividend_disbursed · order_placed · rail_selected · …)

**MCP JSON-RPC 2.0 server** — served both by `functions/api/[[route]].ts` (Cloudflare Pages production) and `server.mjs` (local Node sandbox dev — full port with `webcrypto.subtle.digest` for the pseudo-hash):
- ✅ `GET /api/mcp` — introspection payload (`{ok, protocol, transport, authed, tools[4], resources[3], server}`)
- ✅ `POST /api/mcp` — JSON-RPC 2.0 dispatcher: `ping · initialize · tools/list · resources/list · tools/call`
- ✅ 4 tools: `valuation_avm` (AVM 3.0 · yield · comps) · `conveyancing_verify` (84-jurisdiction pack) · `escrow_disburse` (PoPP-gated escrow → settlement tx hash) · `intent_score` (CRM decay-weighted 0-100 + band)
- ✅ 3 resources: `estate://deals/active · estate://jurisdictions · estate://telemetry/live`
- ✅ Bearer auth via `env.MCP_TOKEN` (Cloudflare) / `process.env.MCP_TOKEN` (server.mjs) — dev leaves auth off, production sets via `wrangler pages secret put MCP_TOKEN`

**7 new route pages** (all zero-drift · lazy-loaded · Framer-Motion hover glow · glass-card backgrounds · TrinityShell-hosted · mobile-adaptive):

| Route | Module | Widgets | Accent |
|-------|--------|---------|--------|
| `/estate-os` | ESTATE OS Control Room | 6-KPI ribbon · 8 module tiles · 10-event activity stream | `TC.indigo` |
| `/ai-core` | EstateBrain™ + MCP Terminal | JSON-RPC 2.0 invoker (4 tools) · trace table · embeddings dashboard (4 channels) | `TC.indigo` |
| `/module/08-fintech` | Regulated Fintech & Settlement | Payment Rails (fiat/stablecoin) with fee breakdown · Escrow Lock Vault (3-state, live calls `POST /api/mcp` `escrow_disburse`) · Lender API Grid (5 lenders · LTV 60-80% · rates 4.2-6.8%) | `TC.emeraldV5` |
| `/module/10-capital-markets` | Investor & Capital Markets | KPI Ribbon (NAV $142.8M · DPI 1.42x · TVPI 2.15x · Net IRR 18.4%) · Waterfall Simulator (hurdle · catch-up · carry split · 3-tier Pref/Catch-up/Carry breakdown) · LP 4-step onboarding wizard (KYC → Accredited → Sub Agr → Wire) | `TC.indigo` |
| `/module/19-asset-management` | Asset Management | 3 EstateBrain™ Action Cards (PROP-A HOLD Dubai · PROP-B REFINANCE London · PROP-C DISPOSE Miami) · Variance Narrative · Attribution Table (Base Rent +2.1% / Cap-rate +1.4% / FX -0.3%) | `TC.violetV5` |
| `/module/22-fractional-ownership` | Fractional Ownership & STO | Reg-D 506(c) / Reg-S / Reg-A+ Tier 2 toggle + compliance checklist · Cap-Table Ledger (7 holders) · Automated Dividend Trigger ($480,000 quarterly pool → KYC-eligible holders → batch receipt) | `TC.violetV5` |
| `/module/23-secondary-marketplace` | Secondary Marketplace | Live Ticker (Lit Price · Δ vs NAV · 24h Vol · AML CLEAR; 3s jitter) · Order Book (6 bids + 6 asks with depth bars + mid-market marker) · Order Entry (side · Limit/Market · price · size · T+0 USDC vs T+2 SWIFT rail · receipt) | `TC.emeraldV5` |

**Responsive mobile+desktop layer** — comprehensive redesign shipped this session:
- ✅ `TrinityShell` — auto-collapse sidebar under **900px** via `matchMedia('(max-width: 899px)')` + `useEffect` listener · collapse button hidden on mobile · `.trinity-main` container class
- ✅ `SHELL_CSS` — global responsive utility classes: `.v5-header-row · .v5-invoke-row · .v5-trace-row · .v5-embed-row · .v5-activity-row · .v5-scroll-x · .v5-footer-stamp · .v5-split-2 · .v5-cards · .v5-kpi-4 · .v5-table-row`
- ✅ Media-query overrides at **1024px** · **768px** · **420px** — grids collapse to 1-col, horizontal-scroll wrappers for 6-column trace/embed tables, invoke row simplifies below 768px
- ✅ Phone-safe grid pattern — replaced `auto-fill minmax(Xpx, 1fr)` with **`auto-fill minmax(min(100%, Xpx), 1fr)`** across ControlRoom, AiCore, RouteSkeleton
- ✅ TrinityShell now advertises 12 routes (2 v5 pages + 5 Capital Layer modules + 5 legacy v4.10 modules + Trinity Hub)

**Path 3a deploy plan**: user-managed `MCP_TOKEN` + BYOK Cloudflare deploy to slug `easy-tenancy-global-os` (deferred until user runs `npx wrangler pages secret put MCP_TOKEN` + activates the `cf-byok-deploy` skill).

### 🆕 **v5.0.0-beta — Capital Layer Module Suite (remaining 6 spec routes)**

**Zero-drift additive follow-up to v5.0.0-alpha** — completes the ESTATE OS™ Capital Layer with the 6 remaining spec modules. All 6 files use the same zero-drift pattern established by the alpha: import `TC/V5FX/glassCardStyle/glassCardAccent/fmtUSD` from `../lib/trinityTokens`, glyphs from `../lib/icons/glyphs` (only pre-existing glyphs — no new glyph additions), wrap in `TrinityShell activePath="/module/XX-name" headerAccent={TC.xxx}` with `Crumb` breadcrumb, apply v5 responsive utility classes, fire per-module analytics events, Framer-Motion hover animations, no `Record<string, React.CSSProperties>` annotation, `as const` on enum-typed CSS literals.

**24 new analytics event names** appended to `src/lib/analytics.ts` — 4 events × 6 modules (`_view` + 3 module-specific actions).

**6 new route pages** (all zero-drift · lazy-loaded · Framer-Motion hover glow · glass-card backgrounds · TrinityShell-hosted · mobile-adaptive):

| Route | Module | Widgets | Accent | MCP tool |
|-------|--------|---------|--------|----------|
| `/module/03-inventory-launch` | Off-Plan & Developer Inventory | 3 Launch selector cards (LMT-MIA · MRT-DXB · AXS-SGP) with absorption progress · Absorption Meter (Absorbed/Reserved/Available stacked bar + current-price lift %) · Wave Pricing Ladder (6 bands Foundation → Wave 5 · elasticity slider 0.2–1.0) · Portal Distribution Grid (PF · Bayut · Dubizzle · Rightmove · Zoopla · Zillow · SRX · Juwai · sync latency + LIVE/SYNCING/DEGRADED status + per-row SYNC) | `TC.amberV5` | — |
| `/module/04-crm-pipeline` | CRM & ZK-Identity Vault | 5-stage kanban (NEW/QUALIFIED/TOURED/OFFER/CLOSED · 7 leads) · Lead cards with band pill (HOT/WARM/NURTURE/COLD) + ZK-proved lock · Decay-weighted intent scorer (decay slider 0.6-1.0 · signal contribution bars · NBA panel) · ZK-Identity Vault (Residency/Liquidity/KYC hash/AML clear rows + regenerate) · signal weights `page_view:6 · form_start:12 · brochure_dl:18 · tour_booked:32 · escrow_intent:40 · signed:55` | `TC.violetV5` | — |
| `/module/05-deal-room` | Deal Room & Conveyancing Copilot | 3 Deal cards (UK AP1 · OQOOD · TRID · clause count + high-risk badge) · 5-step Escrow Timeline (KYC → Signed → Funded → Verified → Settled) · Contract Copilot (clause list with HIGH/MED/LOW pill + FLAG button) · Conveyancing Verifier (calls `POST /api/mcp conveyancing_verify` with `{deal_id, jurisdiction}` → pack/status/issues) | `TC.emeraldV5` | `conveyancing_verify` |
| `/module/06-property-ops` | Property Ops · IoT & Predictive Maintenance | 4-KPI ribbon (Assets 46 · Sensors 12,428 · Pending penalties · MTBF 184d) · 6 IoT alerts stream (HVAC vibration · water pressure · elevator cycles · CO2 · power draw · solar · σ badges + ACK/DISPATCH) · Predictive Maintenance table (7 components · MTBF days · health % color-coded emerald/amber/rose · next service) · SLA Micro-Escrow Debit panel (auto-computed penalty · T+0 USDC · receipt with batch ID) | `TC.cyanV5` | — |
| `/module/12-brokerage` | Brokerage Ops · Roster · Waterfall · Payout | 4-KPI ribbon (Agents 2,847 · GCI YTD $142.8M · Payouts MTD $14.2M · Cycle 47s) · Agent Roster table (6 agents · tier pill BRONZE 50 / SILVER 60 / GOLD 70 / PLATINUM 80% agent split · GCI YTD · conversion · PROMOTE per row) · Commission Waterfall Simulator (deal-value + rate inputs · 4-tier stacked bar Agent/Team Lead/Broker/House · breakdown rows) · Instant Payout Rail (USDC T+0 Circle · batch total · fee estimate · receipt) | `TC.amberV5` | — |
| `/module/24-project-tracker` | Land · BIM · Drone | 2 Project cards (MRT-DXB Marina Phase 2 · HRZ-LDN Warehouse Retrofit · overall % + photogrammetry match %) · BIM Layer Toggle Board (6 layers Structural/Facade/MEP/Interior/Vertical/Landscape + per-layer progress + issue count) · Photogrammetry Diff Panel (big % match · drone last-run SKYCAP-05 LiDAR + 42MP RGB · "Dispatch drone re-flight") · Milestone Ladder (4-5 milestones per project · DONE/CURR/NEXT · escrow amount · "Release current milestone" calls `POST /api/mcp escrow_disburse` → settlement tx receipt) | `TC.indigo` | `escrow_disburse` |

**App wiring** — 6 new `React.lazy(() => import(…))` chunks + 6 `<Suspense><Route/></Suspense>` entries in `src/App.tsx`, plus 6 new `TRINITY_LINKS` entries in `src/components/TrinityShell.tsx` (M03/M04/M05/M06/M12/M24) with proper layer/accent/icon mapping.

**Responsive verification** — every beta chunk includes the SHELL_CSS utility classes (`v5-header-row · v5-split-2 · v5-cards · v5-kpi-4 · v5-scroll-x · v5-footer-stamp · trinity-main`); phone-safe at the 1024/768/420px breakpoints defined in TrinityShell's SHELL_CSS.

**Total ESTATE OS™ Capital Layer routes**: 11 modules + Control Room + AI Core = **13 v5 route pages** (5 alpha + 6 beta + 2 foundational).

### **v4.10 Holy Trinity Blueprint (Monopoly-Grade Global OS)**

**Architecture**: 3 layers × 6 modules × 3 monopoly protocols, unified by a persistent shell sidebar.

- ✅ **Persistent left sidebar** (`TrinityShell` component) — collapsible, localStorage-persisted, seamlessly routes between Robotics Fleet · Construction Engine · Global Marketplace · Financial Core · Portfolio PM · Marketing Hub
- ✅ **Unified mock data universe** (`trinityData.ts`, 31 KB) — 6 flagship projects (MRT-DXB, HRZ-LDN, AXS-SGP, NOR-BER, LMT-MIA, SKY-TYO) with linked BIM systems, safety events, BOM, labor, materials, equipment, escrow milestones (PoPP), underwriting runs, FX routes, tours, demand signals, dynamic pricing, Gantt tasks, risks, interop protocols, zero-vacancy matches
- ✅ **Shared design tokens** (`trinityTokens.ts`) — 3-layer color scheme (amber Physical / emerald Financial / violet Operational) + 6 module accents + fmtUSD/fmtPct/relTime helpers

**Layer 1 (Physical) — Asset & Robotics**
- ✅ `/trinity` — **Holy Trinity Hub** (crown page) — layer diagram, portfolio KPIs, all 3 monopoly protocols live, module launcher grid with layer filter
- ✅ `/fleet` — Fleet Core (from v4.9)
- ✅ `/construct` — **easyConstruct Core** — 3 tabs:
  - **BIM 5D Digital Twin** — isometric SVG building visualization, per-discipline progress bars (Structural · Facade · MEP · Interior · Vertical Transport · Landscape), clash-detection count, per-system cost share, mini-4D cost/schedule/material/health stats
  - **Autonomous Site Safety** — drone-AMR / wearable / CV-camera event feed with OSHA/regional citations (§1926.1424, §1926.100, HSE Work at Height 2005, ACI 318-19 §25, UAE OHS-15/2013), severity coding, "Dispatch Site Rover" action
  - **AI Material Engine** — BOM table with auto-PO status, supplier bench-marking, lead times, cross-link to marketplace

**Layer 2 (Financial) — Marketplace & Capital**
- ✅ `/market` — **easyMarket Axis** — 3 tabs:
  - **Global Labor Exchange** — 7 verified pros (structural engineer, BIM coordinator, MEP engineer, robotics tech, welder, crane op, foreman) with certs (CEng, PE, ICE, AWS D1.1, NCCCO, ROS 2, VDA 5050), ratings, availability
  - **Direct-to-Manufacturer** — 7 materials (steel · cement · glass · solar · fixtures · IoT · CLT timber) with CO₂/unit disclosure, customs status, MOQ
  - **Equipment & AMR Rental** — 6 assets (mobile crane · excavator · drone · Spot AMR · telehandler · scaffold) with AI-dispatch certification + telematics
- ✅ `/capital` — **easyCapital OS** — 3 tabs:
  - **Escrow · PoPP Protocol** — milestone register with `awaiting-inspection` / `verified` / `released` / `disputed` states, drone inspector assignment, proof-scan IDs, gold PoPP explainer strip
  - **Algorithmic Underwriting** — 4 asset runs with AI valuation vs ask, LTV / yield / NOI / retention / construction risk score, Approve/Conditional/Decline recommendations
  - **Cross-Border Liquidity** — 7 FX corridors (USD→AED/GBP/SGD/EUR/JPY/CNY/INR) with spot rate, bps fees, settle time, channel (Stablecoin/SEPA/SWIFT/CIPS/UPI), daily volume

**Layer 3 (Operational) — Governance & Demand**
- ✅ `/project` — **easyProject Pro** — 3 tabs:
  - **Gantt & Spatial Sync** — SVG portfolio Gantt with month-tick grid, discipline colour coding, critical-path highlighting (red pulse markers), progress-fill bars
  - **Predictive Risk Engine** — 6 tracked risks (supply chain · weather · budget · regulatory · labor · safety) with probability / delay days / impact $ / weighted exposure, ML mitigation suggestions
  - **Stakeholder Dashboard** — per-project card grid with physical progress, budget burn, schedule variance, task count, risk count, go-live date
- ✅ `/reach` — **easyReach Engine** — 3 tabs:
  - **Spatial 3D/VR/AR Tours** — 5 tour cards (Pre-construction 3D · WebXR VR · AR iOS/Android · Guided Live Video) with animated play buttons, gradient hero art, views/conversion metrics
  - **Autonomous Demand Matching** — 5 segments (Digital Nomad · Family HNW · Corporate Housing · Student · Retiree) with audience size, intent score bar, best-performing channel, CPM, active campaign ID
  - **Dynamic Yield Renting** — 4 units with base vs AI rent delta, occupancy %, seasonal + macro indices, micro-locational signals — "Uber Surge for real estate"

**3 Monopoly Protocols (surfaced on `/trinity`)**
- ✅ **Proof-of-Physical-Progress** — escrow funds unlock ONLY when autonomous drones physically verify milestone completion against BIM twin. Zero trust. Zero fraud. Live inspection queue with "Verify Now" action.
- ✅ **Universal Hardware-Software Interop** — ROS 2 Humble · VDA 5050 · BACnet · Matter 1.3 · MQTT 5 · OPC UA · KNX · Zigbee 3.0. 8 protocols, 79,712 devices live, certifications tracked (ROS-I, VDMA, BTL, CSA Matter, OASIS 5, OPC Foundation, KNX-Certified, CSA Zigbee)
- ✅ **Cross-Portfolio Zero-Vacancy Router** — AI matches expiring leases with new vacancies globally. 5 live matches (HRZ-LDN→MRT-DXB, MRT-DXB→AXS-SGP, LMT-MIA→LMT-MIA, NOR-BER→NOR-BER, HRZ-LDN→HRZ-LDN), 92% avg match score, 148 vacancy-days saved this cycle.

**Wiring**
- ✅ 6 routes registered in `App.tsx` with lazy loading + Suspense fallbacks
- ✅ 7 vanity aliases (`/blueprint`, `/hub`, `/construction`, `/marketplace`, `/finance`, `/marketing`, `/pm`)
- ✅ Desktop Nav updated: Trinity + Fleet + Capital added (4 primary route links total)
- ✅ Mobile drawer updated: 6 Holy Trinity links added
- ✅ 22 new `EventName` entries in `analytics.ts` (trinity_view · trinity_layer_switched · trinity_router_action · construct_view/tab_switched/bom_generated · market_view/tab_switched/dispatch/purchase_intent · capital_view/tab_switched/escrow_action/underwrite_run · reach_view/tab_switched/tour_launched/price_adjusted · project_view/tab_switched/risk_investigated · popp_verified · interop_inspected)

### v4.9 — easyTenancy Fleet Core (Robotics & Spatial Automation)
- ✅ **Route `/fleet`** — full Robotics Command Center for AMRs, security drones, care units, and maintenance rovers
- ✅ **5 KPI cards** — Active fleet, active missions, avg battery, security incidents, care alerts

## What's completed

### Core platform (restored from webapp_backup — v4.7 foundation)
- ✅ React 19 + TypeScript 5.9 SPA on **React Router v7**
- ✅ Framer Motion v12 sovereign motion system + spatial navigation
- ✅ D3.js v7 force-directed radial map (Canvas)
- ✅ WebAuthn/FIDO2 passkey login + Cloudflare Turnstile bot gate
- ✅ Custom Hono-pattern Node server (`server.mjs`, port 3000) with API endpoints
- ✅ Global Orchestrator + Compliance Engine + demo data + Zod v3 schemas
- ✅ PM2 + `ecosystem.config.cjs` production process manager
- ✅ Vitest unit + edge tests, Playwright e2e tests, GitHub Actions CI

### New in this session — **v4.9 easyTenancy Fleet Core (Robotics & Spatial Automation)**
- ✅ **New route `/fleet`** — a full Robotics Command Center for AMRs, security drones, care units, and maintenance rovers
- ✅ **5 KPI cards** — Active fleet, active missions, avg battery, security incidents, care alerts
- ✅ **Quick Action Bar** — Emergency Fleet Lockdown, Dispatch Security Patrol, Schedule UV-C, Add Hardware Node (ROS 2 / VDA 5050)
- ✅ **Live Spatial Floor Map** (SVG) — 9 zones · 15 live robots with battery rings, pathfinding lines, emergency pulses, per-type markers (🛡️ S / 🩺 C / 📦 D / 🧹 M), 2-second live-tick perturbation
- ✅ **Selected robot telemetry panel** — Unit ID, type, zone, battery + progress bar, connectivity (5G/Wi-Fi 6E/CBRS/Mesh) + signal, firmware/hardware, uptime, current mission; simulated dual-camera stream with ALPR/thermal overlay + Privacy Mode banner
- ✅ **4 tabbed modules**:
  - **A · Physical Security & Perimeter** — Live video stream grid, real-time incident log (breaches / ALPR / thermal), Escort Service queue
  - **B · Care & Community Services** — Non-invasive FMCW radar health monitor (HR, respiration, fall detection), medical + meal delivery logistics, Child Geo-Fence Guardian (UWB) with SVG playground overlay
  - **C · Maintenance & NOI Analytics** — Autonomous inspection logs (roof, HVAC, facade, elevator), Operational Savings widget → **+$297,300 NOI uplift per property · +$9.51M / 32-asset portfolio**
  - **D · Fleet Core Middleware** — Protocol Status Tracker (ROS 2, VDA 5050, BACnet, MQTT, OPC UA, Matter, Zigbee, LoRaWAN) + Zero-Trust Privacy Toggle with edge-kit spec
- ✅ **Zero-Trust Privacy Mode** (ON by default) — residential feeds never leave the property gateway; care robots use radar only, no cameras
- ✅ Wired into Nav (desktop + mobile), plus aliases `/robotics` and `/fleet-core`
- ✅ Lazy-loaded chunk (`FleetCore-*.js` — 54.2 kB / 15.26 kB gzip)
- ✅ New analytics events: `fleet_view`, `fleet_tab_switched`, `fleet_robot_selected`, `fleet_incident_dispatched`, `fleet_action_triggered`, `fleet_lockdown`, `fleet_privacy_toggled`, `fleet_protocol_inspected`, `fleet_stream_toggled`, `fleet_escort_requested`

### v4.8 — ESTATE OS™ Module Map
- ✅ **New route `/estate-brain`** — the full 25-module surface from the 2026.1 Ganymede manual, organized into **6 pillars**:
  1. **AI & Intelligence Core** (EstateBrain™ — 8 engines + MCP server)
  2. **Transaction Layer** (Listings, CRM, Deals, PM, Developer, Marketing, Brokerage, Projects)
  3. **Capital Layer** (Fintech, Investor & Capital Markets, Asset Mgmt, Fractional STO, Secondary marketplace)
  4. **Data & Net-Zero** (Market intel + AVM 3.0, ESG / GRESB / ENERGY STAR / EU EPBD)
  5. **Edge & Sovereign Infrastructure** (Platform, IoT, Security — 38 PoPs · 12 sovereign clouds)
  6. **Global & Trust** (Compliance, Integrations, Mobile, Localization, Success, Governance)
- ✅ Interactive **pillar filter** with layout-animated grid (LayoutGroup + `mode="popLayout"`)
- ✅ Expandable module cards with 3–4 substantive capability bullets each
- ✅ Signature **"AI × Capital × Net-Zero × Edge"** stripe on the intersection story
- ✅ Full trackEvent analytics on pillar switches, card expansions, and CTAs
- ✅ Wired into **Nav** (desktop + mobile drawer) and vanity aliases `/modules` and `/global-os`
- ✅ Lazy-loaded chunk (`EstateBrain-*.js` — 27.6 kB / 9.86 kB gzip)

## Routes

> **v5.2.0-alpha universal nav:** every route below (except `/reos/*` which owns its own shell, and `/` at top-scroll where marketing `<Nav />` leads) is now wrapped by `GlobalNavBar` (back/forward/home + ⌘K search + persona badge + drawer) and — on mobile — `MobileBottomNav` (5 tabs with springy `layoutId` underline). Sign-in modal (`PersonaAuthPanel`) is one click away from every page for all 7 personas.

| Path | Purpose | Status |
|---|---|---|
| `/` | Marketing homepage (hero, monopoly, pricing, referral) | ✅ 200 |
| **`/reos`** | **🆕 Tenancy OS REOS · Global Executive Command Center** (v5.1.0-alpha.hotfix — mobile-first cinematic) | ✅ 200 |
| **`/reos/ledger`** | **🆕 Multi-GAAP Ledger Inspector** — US_GAAP · IFRS · LOCAL_STATUTORY + CSV audit export | ✅ 200 |
| **`/reos/compliance` · `/reos/escrow` · `/reos/title` · `/reos/sovereign`** | **🆕 Session-2 roadmap stubs** (Policy · Fiduciary Guard · Title Adapters · PII Cell) | ✅ 200 |
| `/estate-brain` | ESTATE OS™ 25-Modules Global map (2026.1) | ✅ 200 |
| `/modules`, `/global-os` | Aliases → `/estate-brain` | ✅ 302 |
| **`/fleet`** | **🆕 easyTenancy Fleet Core — Robotics & Spatial Automation** | ✅ 200 |
| `/robotics`, `/fleet-core` | Aliases → `/fleet` | ✅ 302 |
| `/app/demo` | Pre-populated product dashboard | ✅ 200 |
| `/global-dominance` | Holy Trinity dominance blueprint | ✅ 200 |
| `/predictive-os` | Predictive Life OS (6 tabs) | ✅ 200 |
| `/realestate-os` | $100B Real Estate OS (mobile-first) | ✅ 200 |
| `/spatial-staging` | AR / Vision Pro staging | ✅ 200 |
| `/strategy` (`/brain`) | Strategic Brain (4 pillars + AI chat) | ✅ 200 |
| `/security-demo` | Turnstile + WebAuthn demo | ✅ 200 |
| `/app/portfolio`, `/investor` | NOI + Investor previews | ✅ 200 |
| `/org/:orgId/properties/:propId/:section` | Deep property detail | ✅ 200 |
| `/org/:orgId/ai-copilot` | AI copilot deep-link | ✅ 200 |
| `/demo`, `/ai`, `/staging`, `/os`, `/security` | Legacy redirects | ✅ 302 |
| `*` | 404 → auto-redirect home | ✅ 200 |

## API endpoints (server.mjs)

| Method | Path | Response |
|---|---|---|
| GET | `/api/health` | 200 (SPA HTML fallback) |
| GET | `/api/arr` | `{ok,arrUSD,target,pct,ts}` |
| GET | `/api/metrics/live` | `{totalManagers,roiMultiplier,activeUnits,leases,...}` |
| GET | `/api/compliance/jurisdiction` | `{ok,country,regime,gdprApplies,...}` |
| GET | `/api/og?country=UK&title=…` | SVG open-graph image |
| POST | `/api/orchestrator/event` | `{ok:true}` |
| POST | `/api/ai/chat` | Gemini proxy + stub fallback |

## Data models & storage

- **Runtime state**: React hooks + `useLiveMetrics` polling `/api/metrics/live`
- **Analytics**: batched `trackEvent()` → `sendBeacon` (Parquet R2 sink when Cloudflare Pipelines is provisioned via `scripts/provision-analytics.sh`)
- **Schemas**: Zod v3 (`src/lib/schemas.ts`) — PropertySchema, TenantSchema, LeaseSchema, ComplianceEventSchema
- **Persistence (production)**: Cloudflare D1 (SQLite), KV, R2 — bindings are pre-wired in `wrangler.jsonc` (commented, ready to activate)
- **Auth**: WebAuthn/FIDO2 passkeys (`WebAuthnLogin.tsx`) + Turnstile bot gate

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 19 · TypeScript 5.9 · React Router v7 |
| Animation | Framer Motion v12 |
| Visualization | D3.js v7 force-directed Canvas |
| Backend API | Node http (server.mjs) — Hono patterns |
| Build | Vite 6 · @vitejs/plugin-react |
| Deploy target | Cloudflare Pages + GitHub Actions CI |
| Process manager | PM2 (sandbox) |
| Analytics | Custom batched `trackEvent()` + Cloudflare Pipelines → R2 Parquet |
| Auth | WebAuthn/FIDO2 + Turnstile |
| Validation | Zod v3 |
| Testing | Vitest + Playwright |

## User guide

1. **Land on `/`** — see the hero, monopoly, ROI, pricing, and referral sections.
2. **Explore the 25 modules** at `/estate-brain` — filter by pillar (AI, Transaction, Capital, Net-Zero, Edge, Global) and click any card to expand its capability bullets.
3. **Launch the app demo** from `/app/demo` — a pre-populated dashboard showing live compliance, collections, and leases.
4. **See the global dominance blueprint** at `/global-dominance`, the Predictive OS at `/predictive-os`, and the $100B RE OS at `/realestate-os`.
5. **Read the strategy** at `/strategy` — 4 pillars, roadmap, competitive intel, and an AI chat.

## Local development

```bash
# One-time
cd /home/user/webapp && npm install

# Build & start (via PM2, port 3000)
npm run build
fuser -k 3000/tcp 2>/dev/null || true
pm2 start ecosystem.config.cjs

# Smoke test
curl http://localhost:3000/estate-brain

# Logs (non-blocking)
pm2 logs webapp --nostream

# Restart after code change
npm run build && pm2 restart webapp
```

## Deployment

- **Platform**: Cloudflare Pages (project name `weathered-night-72f4` in `wrangler.jsonc`)
- **Status**: ✅ Build passes locally · ✅ 15+ routes 200 · Ready to deploy
- **Deploy**:
  - **Via GitHub Actions**: push to `main` — see `.github/workflows/deploy.yml` (needs `CLOUDFLARE_API_TOKEN` secret with **Cloudflare Pages: Edit**)
  - **From sandbox (BYOK)**: activate the `cf-byok-deploy` skill and follow its steps
  - **From sandbox (Genspark-hosted)**: activate the `gsk-hosted-deploy` skill

## Not yet implemented / recommended next steps

1. **Wire the 25-module map to live tenant data** — currently the module surface is descriptive; next step is to bind each card to a live "installed / configured / usage" status per tenant.
2. **MCP server implementation** — the manual promises `EstateBrain™` exposes an MCP server so external agents can operate ESTATE OS™. Currently referenced in the module copy; ships as a stub endpoint.
3. **Capital layer sandbox** — Fund/REIT/LP dashboards are described in module 10; add a `/capital` route with a live waterfall + NAV widget.
4. **Net-Zero telemetry dashboard** — a route showing sub-meter → GRESB/EPBD conversion; today it's referenced only in the module map.
5. **Tokenization + secondary marketplace UI** — the Reg-D/S/A+ issuance flow (module 22) and order-book UI (module 23) need dedicated pages.
6. **Localization** — add a language switcher wired to the country pack (34 languages incl. RTL/CJK per module 17).
7. **CI/CD deploy activation** — add the `CLOUDFLARE_API_TOKEN` secret to unblock `.github/workflows/deploy.yml`.

## Recent session changes

### v5.5.1-alpha M1.5 → M1.8 — SDMX/XRPL waste anchor + KES-first UX + arithmetic hardening

Four consecutive milestones, tagged `v5.5.1-alpha.m1.5` → `.m1.6` → `.m1.7` → `.m1.8`, land the full **ESTATE OS™ Waste Anchor** pipeline: on-chute disposal event → SDMX 2.1 XML → XML-EXC-C14N → SHA3-512 domain-separated Merkle → XRPL AccountSet+Memo, with a KES-first operator UI and a dedicated `/api/anchor` Cloudflare Pages Functions endpoint.

**Milestone summary**

| Tag | Focus | New surface |
|---|---|---|
| `v5.5.1-alpha.m1.5` | Domain services | `src/modules/waste/{types,services,tests}/*` — PAYT billing (6 currencies · 7 materials · CONFIDENCE_FLOOR=0.75), CryptoAuditService (C14N, SHA3-512, Merkle 0x00/0x01/0x02 domain tags), XrplWasteAnchorService (Client.fundWallet + signed AccountSet memo) |
| `v5.5.1-alpha.m1.6` | 3T+ tokens & viewport | `src/tokens/tokens.ts` (canonical MOBILE_MAX=679, COMPACT_MIN=680, DESKTOP_MIN=1024, WIDE_MIN=1440, MIN_TAP_TARGET_PX=44) + `src/hooks/useViewport.ts` (rAF-coalesced window + container hooks, SSR-safe `computeViewportState`) |
| `v5.5.1-alpha.m1.7` | Cloudflare Functions parity | `POST /api/anchor` mounted in `functions/api/[[route]].ts` via `functions/lib/wasteAnchor.ts`; `dryRun` short-circuits before network I/O; live mode faucet-funds an ephemeral testnet wallet or uses `XRPL_SECRET_SEED`; 12 edge tests prove byte-identical Merkle root vs `XrplWasteAnchorService` direct call |
| `v5.5.1-alpha.m1.8` | KES-first UX & arithmetic precision | `src/routes/WasteAnchor.tsx` (KES default with `Ksh` locale grouping) · `src/lib/wasteAnchorMoney.ts` (fixed-point integer minor units, no float arithmetic) · Playwright `tests/e2e/waste-anchor.spec.ts` (demotion, hex roundtrip, tap-target @ 375px) · 85% scoped coverage floor · `useIsMobile` deprecated in favour of `useViewport().isMobile` |

**`POST /api/anchor` contract**

```
POST /api/anchor
Content-Type: application/json

Body:
  {
    "buildingId":  string,          // required
    "batchId":     string,          // optional (auto-generated when omitted)
    "currency":    "USD" | "EUR" | "GBP" | "KES" | "AED" | "CAD",  // default USD
    "events":      DisposalEventInput[],   // 1..N events
    "dryRun":      boolean          // default false; true = pure Merkle, no XRPL I/O
  }

200 →
  {
    "ok":            true,
    "mode":          "dryRun" | "live",
    "buildingId":    string,
    "batchId":       string,
    "records":       [{ eventId, materialType, effectiveMaterial, currency,
                        weightKg, netCharge, demotedDueToLowConfidence,
                        merkleLeafHash, c14nDigest }],
    "merkle":        { merkleRootHash, internalRootHash, leafHashes[], leafCount },
    "memo":          { memoType, memoFormat, memoData, payload },  // hex uppercase
    "hazardousFlaggedCount": number,
    "timestamp":     string,
    "xrpl":          XrplAnchorResult   // present only in live mode
  }

400 invalid_json  — body wasn't parseable JSON
400 invalid_body  — validation failed (detail includes offending field)
500 anchor_failed — live mode XRPL error (faucet / connect / submit)
```

**Live mode configuration**

Configure the wallet seed and (optionally) the testnet endpoint via Wrangler:

```bash
# Production (Cloudflare Pages)
wrangler pages secret put XRPL_SECRET_SEED --project-name webapp
# Optional override; defaults to wss://s.altnet.rippletest.net:51233
wrangler pages secret put XRPL_TESTNET_URL --project-name webapp

# Local development
# Create .dev.vars in the repo root (already git-ignored):
#   XRPL_TESTNET_URL="wss://s.altnet.rippletest.net:51233"
#   XRPL_SECRET_SEED="sEd…"       # non-production seed only
# Then run: wrangler pages dev dist
```

When `XRPL_SECRET_SEED` is unset in live mode, the handler funds an ephemeral testnet wallet via the XRPL testnet faucet (`https://faucet.altnet.rippletest.net/accounts`) — safe for demos, but does not persist a stable account.

**Verification (real gate numbers, M1.8 HEAD)**

- `npx tsc --noEmit` — 0 errors
- `CI=1 npx vitest run` — 229 / 229 pass across 10 files
- `npm run build` — clean, dedicated `WasteAnchor-*.js` lazy chunk emitted
- Playwright `tests/e2e/waste-anchor.spec.ts` authored (3 blocks: demotion, hex roundtrip, tap-target @ 375px); requires `wrangler pages dev` to run against the Functions layer

**File ledger for the four milestones**

| File | Milestone | Notes |
|---|---|---|
| `src/modules/waste/types/waste.ts` | M1.5 | 7 material types, 6 SupportedCurrency, `DisposalEventInput`, `ProcessedDisposalRecord` |
| `src/modules/waste/services/PAYTBillingEngine.ts` | M1.5 | 6-ccy × 7-material tariff card; KES row present; CONFIDENCE_FLOOR=0.75 |
| `src/modules/waste/services/CryptoAuditService.ts` | M1.5 | Static: canonicalizeXml, sha3_512, computeLeafHash (0x00), computeMerkleNodeHash (0x01), computeMerkleRootHash (0x02 ‖ uint32_BE(leafCount) ‖ SHA3-512(internal)) |
| `src/modules/waste/services/XrplWasteAnchorService.ts` | M1.5 | `Wallet.fromSeed` + autofill + `submitAndWait` asserting `tesSUCCESS` |
| `src/modules/waste/tests/wastePipeline.spec.ts` | M1.5 + M1.8 | +3 float-drift assertions in M1.8 (KES total roundtrip, `0.1+0.2 = 0.30`, XRP drops) |
| `src/tokens/tokens.ts` | M1.6 | Canonical 3T+ registry + 4-tier alias re-projection |
| `src/hooks/useViewport.ts` | M1.6 | `useViewport()` + `useContainerViewport(ref)` + `computeViewportState(w, h?)` |
| `src/hooks/index.ts` | M1.8 | `useIsMobile` deprecated → `useViewport().isMobile` |
| `functions/lib/wasteAnchor.ts` | M1.7 | Validation + PAYT/Merkle/memo delegation + dry-run / live |
| `functions/api/[[route]].ts` | M1.7 | Surgical +9 lines: import + Env `XRPL_*` + `app.post('/api/anchor', …)` |
| `tests/edge/anchor.spec.ts` | M1.7 | 12 contract-parity tests (validation, dry-run, byte-parity Merkle) |
| `src/lib/wasteAnchorMoney.ts` | M1.8 | Fixed-point money helpers (`toMinorUnits`, `sumMinorUnits`, `driftSafeSum`, `formatKes`, `formatXrpDrops`) |
| `src/routes/WasteAnchor.tsx` | M1.8 | KES-first form + result panel; every control ≥ MIN_TAP_TARGET_PX (44px) |
| `src/App.tsx` | M1.8 | Surgical +8 lines: `lazy(() => import('./routes/WasteAnchor'))` + `<Route path="/waste-anchor" />` |
| `tests/unit/tokens.spec.ts` | M1.8 | Pure-function coverage of 3T+ classifier + a11y tokens |
| `tests/unit/wasteAnchorMoney.spec.ts` | M1.8 | ~45 assertions covering fixed-point arithmetic + formatters |
| `tests/e2e/waste-anchor.spec.ts` | M1.8 | Playwright: demotion, hex roundtrip, tap-target @ 375px |
| `.dev.vars` | M1.8 | Local Wrangler env template (git-ignored); documents `XRPL_TESTNET_URL` + `XRPL_SECRET_SEED` |
| `vitest.config.ts` | M1.8 | Scoped 85% coverage floor on 4 touched-file globs (Q3=c@85%) |

### v5.3.1-alpha — MetaMCP hybrid gateway integration

Applied per user directive: *"Please complete the MetaMCP hybrid integration across our repository … Create ops/metamcp.service using the hardened v3 systemd unit file … Implement the /ai-core worker route handler using fetch() to proxy JSON-RPC 2.0 payloads to env.METAMCP_GATEWAY_URL … Pipe the streaming SSE (text/event-stream) response directly back to the client."*

**Zero-regression rollout.** When `METAMCP_GATEWAY_URL` is **unset**, the existing in-repo `/api/mcp` dispatcher (4 tools · 3 resources · `MCP_TOKEN` Bearer auth) keeps serving every request exactly as before. When the secret **is** set, the same POST endpoint transparently proxies to the remote hardened MetaMCP gateway (see [`ops/metamcp.service`](./ops/metamcp.service)) and streams SSE frames straight back to the browser. The React client at [`/ai-core`](./src/routes/AiCore.tsx) needs zero changes — its `callMcp()` helper already POSTs JSON-RPC 2.0 to `/api/mcp`.

**Integration architecture**

```
   Browser (/ai-core · AiCore.tsx)
        │  POST /api/mcp   { jsonrpc:"2.0", method, params, id }
        ▼
   Cloudflare Pages Function (functions/api/[[route]].ts)
        │
        ├── env.METAMCP_GATEWAY_URL set?
        │      │
        │      ├── YES ─► fetch(<gateway>/mcp, Bearer env.METAMCP_BEARER_TOKEN,
        │      │           body: request.body (streamed))
        │      │           └─► new Response(upstream.body /* SSE */, {status, headers})
        │      │                └── text/event-stream piped unchanged to browser
        │      │
        │      └── NO  ─► local dispatcher (initialize · ping · tools/list ·
        │                 tools/call · resources/list) — v5.0 behaviour
        │
        └── /api/mcp/gateway/*  → transparent catch-all proxy for nested
                                  MCP endpoints (SSE streams, tool sub-routes,
                                  gateway health probes) when configured
```

**New files (3):**

| Path | Purpose |
|---|---|
| **`ops/metamcp.service`** | Hardened v3 systemd unit — `User=metamcp`, `CapabilityBoundingSet=` (drop all caps), `SystemCallFilter=@system-service` + explicit denylist, `LogsDirectory=metamcp` / `RuntimeDirectory=metamcp` / `StateDirectory=metamcp`, `ProtectSystem=strict`, `PrivateTmp/Devices/Users=true`, `ProtectKernelTunables/Modules/Logs=true`, `LockPersonality`, `RestrictRealtime/Namespaces/SUIDSGID`, `RemoveIPC`, exponential-backoff restart (`RestartSteps=5` · `RestartMaxDelaySec=1m`), `MemoryMax=1G` / `CPUQuota=150%`. Target `systemd-analyze security` exposure ≤ 2.0. |
| **`ops/install-metamcp.sh`** | Idempotent provisioning script (`chmod +x` set) — creates `metamcp` system user, prepares `/opt/metamcp`, installs the unit, `systemctl daemon-reload && systemctl enable --now`, runs `systemd-analyze security metamcp.service`. |
| **`ops/README.md`** | Full operator docs: prerequisites, install one-liner, sandbox verification (`systemd-analyze security metamcp.service`), log tailing (`journalctl -u metamcp -f`), everyday commands, wiring the Cloudflare secrets, uninstall. |

**Modified files (3):**

| Path | Change |
|---|---|
| **`functions/api/[[route]].ts`** | ➕ `Env.METAMCP_GATEWAY_URL?: string` + `Env.METAMCP_BEARER_TOKEN?: string`. ➕ `proxyToMetaMcp()` helper (streams `request.body`, injects `Authorization: Bearer ${env.METAMCP_BEARER_TOKEN}`, strips hop-by-hop headers, returns `new Response(upstream.body, …)` so `text/event-stream` flushes unchanged). ➕ `app.all('/api/mcp/gateway/*')` catch-all for nested MCP endpoints. ⇢ `app.post('/api/mcp')` now prefers the gateway when `METAMCP_GATEWAY_URL` is set (POST forwarded to `<gateway>/mcp`); otherwise falls through to the existing local dispatcher. ⇢ `app.get('/api/mcp')` health payload now reports `mode: 'gateway' \| 'local'` and echoes `{ url, authed }` when in gateway mode. |
| **`wrangler.jsonc`** | ➕ `vars` block with `METAMCP_GATEWAY_URL: ""` (safe default → local dispatcher) + inline comment documenting `METAMCP_BEARER_TOKEN` as a Wrangler secret (never committed). |
| **`README.md`** | This section. |

**Cloudflare Pages setup (one-time, per environment):**

```bash
# 1. Public HTTPS URL of the remote MetaMCP gateway (e.g. https://mcp.example.com)
npx wrangler pages secret put METAMCP_GATEWAY_URL --project-name weathered-night-72f4

# 2. Bearer token the gateway expects (matches whatever the VPS is configured with)
npx wrangler pages secret put METAMCP_BEARER_TOKEN --project-name weathered-night-72f4

# 3. Verify — hit the introspection endpoint after redeploy:
curl https://<your-pages-domain>/api/mcp
# → { ok:true, mode:"gateway", gateway:{ url:"…", authed:true }, tools:[…], … }
```

**VPS-side setup (one-time):**

```bash
# On the target Linux VPS, after deploying the built MetaMCP artifact to /opt/metamcp:
chmod +x ops/install-metamcp.sh
sudo ops/install-metamcp.sh

# Verify the sandbox surface:
sudo systemd-analyze security metamcp.service        # expect: exposure ≤ 2.0, "OK"

# Tail live logs:
sudo journalctl -u metamcp -f
```

**Rollback:** unset `METAMCP_GATEWAY_URL` (via `wrangler pages secret delete METAMCP_GATEWAY_URL --project-name weathered-night-72f4`) and redeploy — the Pages Function reverts to the in-repo local dispatcher on the next request.

---

### v5.3.0-alpha — Internal Sales & Marketing Team Engine

Applied per user directive: *"Master Directive: Complete Internal Sales & Marketing Team Engine … an elite Full-Stack Platform Architect and L4 Autonomous AI Developer … architect, build, and integrate a comprehensive, production-grade Internal Sales & Marketing Team Engine across the entire application architecture … end-to-end tooling from lead generation and multi-channel outreach to pipeline management, task assignment, and inventory-linked fulfillment."*

Where v5.2.5-α simply relabeled `/reach` for discoverability, v5.3.0-α ships the **actual dashboard** the directive asked for — a first-class four-tab operating cockpit for internal reps, marketing coordinators, and ops managers, sitting on its own route (`/sales-engine`) with a full domain model, reactive store, seed data, and one-click order/contract generation.

**Route topology (final):**

| URL | Serves |
|---|---|
| **`/sales-engine`** | 🆕 Internal Sales & Marketing Team Engine (this build) |
| `/sales` · `/sales-marketing` · `/marketing` · `/growth` · `/crm` · `/team` · `/pipeline` | 7 vanity aliases → `/sales-engine` |
| `/reach` | Kept as **easyReach** (customer-facing Spatial Web / demand-matching / dynamic yield — unchanged) |

**New files (2):**

| File | Lines | Purpose |
|---|---|---|
| `src/lib/salesEngineStore.ts` | 631 | Domain model (Lead, TeamMember, Task, Interaction, Template, InventoryItem, Order) + reactive `useSyncExternalStore` hook with localStorage persistence, seed data (7 team members · 28 leads · 14 tasks · 8 templates · 10 inventory SKUs · 5 orders), action creators (moveLead, updateLead, createLead, completeTask, createTask, logInteraction, useTemplate, reserveInventory, createOrder, advanceOrder) + KPI selectors |
| `src/routes/SalesMarketingEngine.tsx` | 1290 | Four-tab dashboard route wired to the store |

**Module A · Advanced Internal CRM & Lead Command Center** ("CRM Pipeline" tab)

| Feature | Implementation |
|---|---|
| Unified pipeline & contact management | Centralized `Lead[]` in store — name, company, email, phone, city/country, type (retail-buyer · wholesale · investor · tenant · partner), source (website · referral · whatsapp · email · event · cold-call · partner · social), tags, priority, owner, value, probability, score, notes |
| Advanced filtering, search, tagging | Full-text search across name / company / email / city / tags · stage filters (7 stages) · priority filters (low / med / high / critical) · owner scope picker · combined filter reducer |
| Kanban drag-and-drop pipeline | 6 primary stages (Inbound → Qualified → Sample/Demo Sent → Negotiation → Contract Signed → Active Account) + Closed-Lost sink · native HTML5 drag-and-drop with `dataTransfer` · drop targets animate accent glow · store action `moveLead()` auto-creates follow-up task + logs stage-change interaction |
| Table workflow | Wrapped in `.gan-table-responsive` with `data-label` on every `<td>` — collapses to `.gan-card-stack` layout below 640 px |
| Lead detail drawer | Full metadata grid, contact/owner block, stage-advance buttons (44 px min), inventory link + one-click **Create Invoice**, open-tasks list, live interaction log with quick-note input (Enter to log) |

**Module B · Omnichannel Outreach & Sales Automation Suite** ("Outreach Suite" tab)

| Feature | Implementation |
|---|---|
| Template & Script Library | 8 pre-built templates across email · WhatsApp · call · meeting channels · categories: intro, follow-up, demo-invite, negotiation, close, re-engage, onboarding · variable slots (`{{first_name}}`, `{{property}}`, `{{counter_price}}`, …) · use-count + last-used timestamp · channel filter chips |
| Automated Task Triggers | 4 documented automations wired into `salesEngineActions.moveLead()`: **Stage Advance → Follow-up** (24 h SLA · 4 h for contract), **30-day Dormant → Re-engage**, **Overdue → Escalate**, **Contract Signed → Handoff** · auto-tasks tagged `triggeredBy: 'auto-stage-change'` and surface in a live feed |
| Interaction History Log | Chronological timeline per-lead (call · WhatsApp · email · meeting · SMS · in-person) with direction (in/out) and outcome (connected · no-answer · positive · objection · closed-won · closed-lost · demo-set) · global recent-activity feed showing latest 12 interactions across all leads |
| Template modal | Copy-to-clipboard + increment `useCount` in one click — persisted via localStorage |

**Module C · Operations, Inventory & Fulfillment Synchronization** ("Ops & Inventory" tab)

| Feature | Implementation |
|---|---|
| Live Product/Asset Catalog | 10 SKUs spanning `property`, `unit`, `batch` (REIT subscription, CAT bond), `service`, `digital` — with real-time `quantity − reserved` availability, status (available / reserved / sold / restock), location, attrs, price · category + status filters + full-text search |
| Order & Contract Generation | Store action `createOrder(leadId, itemId, qty, docType)` — one-click conversion from lead drawer · sequential invoice code (`INV-2026-nnnn`) · 5 % tax auto-computed · 4 doc types (invoice / agreement / trust-doc / llc-doc) · order pipeline `draft → sent → signed → paid` with **Advance** action |
| Reserve inventory | `reserveInventory(itemId, qty)` — atomically bumps `reserved` count with availability check |
| Internal Performance Metrics | KPI ribbon: **Weighted Pipeline** (Σ value × probability), **Won This Month**, **Tasks Open** (+ overdue count), **Win Rate** · per-user quota attainment progress bars (green ≥ 100 %, blue ≥ 70 %, amber below) · pipeline-by-stage snapshot with deal count + weighted value bars |

**Command Center tab (aggregate view)**

- **4 KPI cards** — weighted pipeline · won this month · tasks open (with overdue) · win rate
- **Team Performance** grid — per-rep quota attainment progress bars (`role !== 'ops' && role !== 'marketing'` scope when All is selected)
- **Priority Queue** — top 8 open tasks sorted by due-time · overdue tasks marked with red left-border and `OVERDUE` label · one-click complete
- **Hot Leads** — top 8 by score (0-100), score-color-coded (≥80 green · ≥60 gold · else info-blue)
- **Pipeline Snapshot** — per-stage deal count + weighted value bar

**Owner Scope Picker (persistent across tabs)** — click "All team" or any rep's avatar to filter every KPI, queue, hot-list, and pipeline breakdown to just that owner. Fires `sales_engine_owner_switched` analytics.

**Analytics (`src/lib/analytics.ts`)** — 15 new `EventName` union members:

```
sales_engine_view · sales_engine_tab_switched
sales_engine_lead_moved · sales_engine_lead_opened · sales_engine_lead_created
sales_engine_task_completed · sales_engine_task_created
sales_engine_template_used · sales_engine_template_copied
sales_engine_interaction_logged
sales_engine_inventory_reserved · sales_engine_order_created · sales_engine_order_advanced
sales_engine_owner_switched · sales_engine_filter_changed
```

**Mobile-First (CSS Layer 43) enforcement**

Every interactive control in the engine satisfies the ≥44×44 rule via the shared `touchTarget` object literal `{ minHeight: 44, minWidth: 44, WebkitTapHighlightColor: 'transparent', touchAction: 'manipulation' }` applied to:

| Control | Applied |
|---|---|
| Owner-scope chips (avatar buttons) | ✅ |
| Stage/priority/channel/status/category filter chips | ✅ |
| Table view / Kanban view toggles | ✅ |
| Search inputs (`minHeight: 44`) | ✅ |
| Kanban cards (drag/drop + keyboard-open with Enter/Space) | ✅ |
| Stage-advance buttons in lead drawer | ✅ |
| Task-done buttons (40×40 icon-only, on 44 px rows) | ✅ |
| Template cards | ✅ |
| Reserve / Advance / Open buttons in tables | ✅ |
| Log-note input + submit | ✅ |
| Modal close (✕) buttons | ✅ |

Tables opt into `.gan-table-responsive` with `data-label` on every `<td>`. Cards use `.gan-glass` and `.gan-fluid-cards`. Drawer opts into `.gan-drawer-mobile` (bottom-sheet on <640 px). Kanban board scrolls horizontally with `WebkitOverflowScrolling: 'touch'` + `scrollSnapType: 'x proximity'`. Drawer padding uses `env(safe-area-inset-bottom, 20px)` for notched devices.

**Discoverability**

| Surface | Change |
|---|---|
| Dashboard `/estate-os` ecosystem grid (ModulesGrid.tsx) | New **Sales & Marketing** tile (S&M code, rose accent, `featured: true`) at `path: '/sales-engine'`; `/reach` retained separately as easyReach (Ads · Growth · VR Tours) |
| ⌘K global search (RouteMap.ts) | New entry `/sales-engine` with 17 keywords: sales · marketing · engine · team · crm · pipeline · kanban · leads · deals · templates · outreach · whatsapp · campaigns · attribution · funnel · quota · orders |
| URL vanity aliases (App.tsx) | 7 aliases: `/sales`, `/sales-marketing`, `/marketing`, `/growth`, `/crm`, `/team`, `/pipeline` — all `<Navigate to="/sales-engine" replace />` |

**Verification (v5.3.0-alpha):**

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ **0 errors** (v5.2.5-α → v5.3.0-α; +2,000 lines) |
| `npm run build` | ✅ **clean 7.92 s** — `SalesMarketingEngine-*.js` 65.14 kB (gzip 17.32 kB) — code-split, lazy-loaded |
| PM2 `webapp` | ✅ online — pid 63545 · serving v5.3.0-α |
| Bundle fetch | ✅ `GET /assets/SalesMarketingEngine-*.js → 200 (65,140 B)` |
| `curl /sales-engine` | ✅ 200 |
| `curl /sales · /sales-marketing · /marketing · /growth · /crm · /team · /pipeline` | ✅ all 200 (7 vanity aliases) |
| `curl /reach` (unchanged) | ✅ 200 |
| No regression on `/predictive-os · /estate-brain · /estate-os · /` | ✅ all 200 |

**Files touched (6):**
- `src/lib/salesEngineStore.ts` — 🆕 domain store (631 lines)
- `src/routes/SalesMarketingEngine.tsx` — 🆕 dashboard route (1,290 lines)
- `src/lib/analytics.ts` — +15 event names
- `src/App.tsx` — +1 lazy import, +1 route, +7 aliases
- `src/components/ModulesGrid.tsx` — split `/reach` tile into 2 (Sales & Marketing + easyReach)
- `src/components/globalNav/RouteMap.ts` — split entry, +17 keywords

### v5.2.5-alpha — Knowledge Graph mobile-first + Sales & Marketing Engine visibility

Applied per user directive: *"Commit all changes Review all pending tasks and complete, commit changes and ensure knowledge graph is configured with mobile first features. Sales and marketing engine is not visible"*

**Two concerns addressed in this pass:**

**A. Knowledge Graph — mobile-first upgrade (CSS Layer 43 conformance)**

Auditing `RadialKnowledgeGraph` (`src/lib/v5Interactions.tsx`, sole consumer `PredictiveLifeOS.tsx:1422`) revealed the following gaps under the 44×44 rule:

| Gap | Before | After (v5.2.5-α) |
|---|---|---|
| Interactive node hit target | `r=16` → 32 px diameter (below 44 min) | Invisible hit-circle `r=max(p.r+8, 22)` → **≥44 px diameter** |
| Chrome/iOS blue tap flash | Present | `WebkitTapHighlightColor: 'transparent'` |
| 300 ms click delay | Present | `touchAction: 'manipulation'` |
| Focus outline artifact | Default | `outline: 'none'` (kept `role="button"` for AT focus ring via UA) |
| A11y — `role`, `aria-label` | Missing | `role="button"` + `aria-label` (includes score when present) |
| Keyboard parity (WCAG 2.1) | None | `tabIndex={0}` + `onKeyDown` handler for Enter + Space |
| Visual children stealing pointer events | Halo/node/labels caught taps individually | `pointerEvents="none"` on all visuals; only invisible hitbox catches |

**B. Sales & Marketing Engine visibility**

The `/reach` route (built as "easyReach") was labeled opaquely as *easyReach · Ads · Growth* in ModulesGrid — no dashboard user would recognize it as the Sales & Marketing Engine. Three surfaces fixed:

| Surface | File | Change |
|---|---|---|
| Dashboard ecosystem grid (`/estate-os`) | `src/components/ModulesGrid.tsx:99` | `label: 'easyReach' → 'Sales & Marketing'`, `sub: 'Ads · Growth' → 'easyReach · Ads · Growth · Attribution'`, added `featured: true` for prominence, code `RCH → S&M` |
| ⌘K global search (RouteMap) | `src/components/globalNav/RouteMap.ts:85` | Label `easyReach → Sales & Marketing`; keywords extended to `['sales','marketing','engine','growth','ads','attribution','reach','campaigns','leads','crm','funnel']`; synopsis rewritten |
| URL discoverability | `src/App.tsx:918` | Added `/sales`, `/sales-marketing`, `/growth` `<Navigate to="/reach" replace />` vanity aliases (alongside pre-existing `/marketing`) |

Complementary fix on **EstateBrain** where module id `marketing` (n:11) *"Marketing & Growth Engine"* already renders under **Transaction Layer** pillar (no filter bug; render logic verified):

| Element | Before | After |
|---|---|---|
| `S.pillBtn` (pillar filter tabs) | `padding: 10px 16px` → ~36 px | `padding: 12px 18px` + `minHeight: 44` + `minWidth: 44` + `touchAction: 'manipulation'` + `WebkitTapHighlightColor: 'transparent'` |
| `S.filterInner` overflow | Default | `WebkitOverflowScrolling: 'touch'` |

**Verification (v5.2.5-alpha):**

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors |
| `npm run build` | ✅ clean (8.24 s; `v5Interactions-*.js` 19.45 kB gzip 6.82 kB, `EstateBrain-*.js` 27.92 kB gzip 9.94 kB) |
| PM2 `webapp` | ✅ online — serving v5.2.5-alpha |
| `curl /predictive-os` | ✅ 200 (knowledge graph route) |
| `curl /estate-brain` | ✅ 200 |
| `curl /reach` | ✅ 200 (Sales & Marketing engine) |
| `curl /sales` | ✅ 200 (new alias) |
| `curl /sales-marketing` | ✅ 200 (new alias) |
| `curl /marketing` | ✅ 200 (pre-existing alias) |
| `curl /growth` | ✅ 200 (new alias) |

**Discoverability paths for Sales & Marketing Engine (all live):**
1. Dashboard `/estate-os` → **"Sales & Marketing"** tile (featured, rose accent, code S&M) in the ecosystem grid
2. ⌘K global search → type any of `sales`, `marketing`, `growth`, `ads`, `attribution`, `leads`, `funnel`, `crm`, `campaigns` → surfaces the entry
3. Direct URL: `/reach`, `/sales`, `/sales-marketing`, `/marketing`, `/growth` (all redirect to `/reach`)
4. EstateBrain → **Transaction Layer** pillar → module #11 *"Marketing & Growth Engine"* card

### v5.2.4-alpha — Comprehensive Mobile-First Audit · Predictive OS + 6 remaining tables

Applied per user directive: *"Comprehensive System Directive: Mobile-First Audit, Refactoring & Completion — perform an exhaustive, zero-hallucination audit across the entire application—specifically targeting `/predictive-os` and all remaining unoptimized routes—to enforce strict mobile-first design patterns … Ensure every data grid, complex table, and high-density dashboard view converts to mobile-optimized `.gan-card-stack` layouts on viewports < 640 px … Guarantee all interactive elements meet the strict minimum touch target size of 44 × 44 px adhering to CSS Layer 43 design tokens."*

**Discovery pass (audit only — 44-route inventory)** — programmatic grep across `src/routes/`, `src/components/`, `src/pages/` produced this exact gap list:

| Gap | Count | Files |
|---|---|---|
| `<table>` present, `.gan-table-responsive` missing | **7 files** | `AppDemo · GlobalDominance · EasyConstruct · EasyMarket · EasyCapital · EasyReach · reos/LedgerInspector` |
| PredictiveLifeOS interactive style tokens < 44 px min | **7 tokens** | `personaChip (40) · indexChip (38) · relatedPill (~28) · promptChip (~40) · solutionCard · actionRow · certCard` |
| PredictiveLifeOS RippleButton call sites < 44 px | **4 sites** | Lines 1364 / 1367 / 1728 / 1731 (all at `padding: '10px 20px'` ≈ 40 px) |

**Zero-hallucination note** — one of the 7 table files (`reos/LedgerInspector.tsx`) was found on inspection to **already ship a hand-crafted 560 px card fallback** (`.reos-tb-table-wrap { display: none }` + `.reos-tb-card-wrap { display: block }` for both the Trial-Balance and Postings tables). It was **excluded from the wrap-in-`.gan-table-responsive` pass** — over-writing it would have caused double-rendering. Six tables refactored, one intentionally skipped after inspection.

**Phase A — `src/routes/PredictiveLifeOS.tsx` (target route)**

Refactored the `S` styles object so every interactive token meets **≥ 44 × 44 px** and applies `WebkitTapHighlightColor: 'transparent' + touchAction: 'manipulation'` (per CSS Layer 43 conformance):

| Token | Before | After |
|---|---|---|
| `personaChip` | `padding: '10px 14px'` · `minHeight: 40` | `padding: '12px 14px'` · `minHeight: 44 · minWidth: 44` + tap-highlight + touch-action |
| `indexChip` | `padding: '9px 14px'` · `minHeight: 38` | `padding: '12px 14px'` · `minHeight: 44 · minWidth: 44` + tap-highlight + touch-action |
| `solutionCard` | grid, cursor:pointer, no min-height | same + `minHeight: 60` + tap-highlight + touch-action |
| `relatedPill` | `padding: '5px 10px'` (~28 px) | `padding: '12px 14px'` · `minHeight: 44 · minWidth: 44` + tap-highlight + touch-action |
| `certCard` | (already `minHeight: 132`) | + tap-highlight + touch-action |
| `actionRow` | grid, cursor:pointer, no min-height | + `minHeight: 64` + tap-highlight + touch-action |
| `promptChip` | `padding: '10px 14px'` (~40 px) | `padding: '12px 16px'` · `minHeight: 44 · minWidth: 44` + tap-highlight + touch-action |

Four `<RippleButton>` call sites (persona owner CTA · Try demo CTA · Open Copilot CTA · Persona owner CTA in copilot section) upgraded from `padding: '10px 20px'` → `padding: '12px 22px'` + explicit `minHeight: 44`.

**Phase B — Wrap 6 remaining tables in `.gan-table-responsive` + add `data-label`**

| File | Cols wrapped | data-label attrs added |
|---|---|---|
| `AppDemo.tsx` | 7 (ID · Name · Units · Occ % · NOI % · Trend · Status) | 7 |
| `GlobalDominance.tsx` | 4 (Platform · Weakness · Fix · Impact) | 4 |
| `EasyConstruct.tsx` | 10 (Line · Item · Category · Qty · Unit $ · Line $ · Best Supplier · Lead · Auto-PO · Route) | 10 |
| `EasyMarket.tsx` | 9 (Item · Category · Manufacturer · Unit $ · MOQ · Lead · Customs · CO₂ · Action) | 9 |
| `EasyCapital.tsx` | 6 (Route · Spot Rate · Fee bps · Settle · Channel · 24h Volume) | 6 |
| `EasyReach.tsx` | 10 (Unit · Asset · Base Rent · AI Rent · Δ · Occ · Seasonal · Macro · Micro · Action) | 10 |

**Total surgical opt-ins:** **6 wrapper divs + 46 `data-label` attributes**, zero data-model or business-logic changes.

**Verification (v5.2.4-alpha):**

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ **0 errors** (28.7 s) |
| `npm run build` | ✅ Clean — built in **8.12 s** |
| PredictiveLifeOS bundle | 92.67 kB → **93.24 kB** (+0.57 kB · +0.6 %) — proportional to CSS token additions |
| `curl /predictive-os` | ✅ **HTTP 200** |
| `curl /app/demo` | ✅ **HTTP 200** |
| `curl /construct` | ✅ **HTTP 200** |
| `curl /market` | ✅ **HTTP 200** |
| `curl /capital` | ✅ **HTTP 200** |
| `curl /reach` | ✅ **HTTP 200** |
| `curl /module/27-family-bank` | ✅ **HTTP 200** (regression check) |
| `curl /reos/ledger` | ✅ **HTTP 200** (regression check) |
| `curl /global-dominance` | ✅ **HTTP 200** |
| PM2 `webapp` | ✅ online — serving v5.2.4-alpha |

**Coverage after this pass (cumulative across v5.2.2-α + v5.2.3-α + v5.2.4-α):**
- **11 out of 12 `<table>`-bearing routes** now opt into `.gan-table-responsive` (`M03 · M06 · M08 · M12 · M22 · M27 · AppDemo · GlobalDominance · EasyConstruct · EasyMarket · EasyCapital · EasyReach`) — the 12th (`reos/LedgerInspector`) has a custom 560 px hand-crafted card fallback that supersedes the generic layer-43 behavior.
- **PredictiveLifeOS** now fully conformant: 3-col main grid collapses to 1-col via `isMobile`, all seven interactive style tokens ≥ 44 px + tap-highlight, all four hero-CTA RippleButtons ≥ 44 px.
- **Module 27 Family Bank** (built in v5.2.3-α) already ships with `.gan-drawer-mobile` bottom-sheet modal + `.gan-fluid-cards` KPIs + `.gan-table-responsive` ledger — no regression.

### v5.2.3-alpha — M27 · Family Bank / Infinite Banking · Trust Asset Loop

Applied per user directive: *"Module Integration Directive: Infinite Banking / Family Bank & Trust Asset Loop. Integrate the 'Infinite Banking / Trust Asset Loop' workflow into our existing Ganymede v2026.1 platform (extending modules such as M08 Fintech, M03 Ledger, and M22 Fractional Ownership). The system must abstract complex legal, tax, and insurance operations into a seamless, highly intuitive consumer-facing experience adhering to our existing CSS Layer 43 design tokens, touch targets, and responsive card-stack patterns."*

**New route** — `/module/27-family-bank` — 1,259-line single-file module (`src/routes/Module27FamilyBank.tsx`, gzip **9.17 kB**, 35.59 kB raw) that ships **all four widgets** from the directive:

| Widget | Contents |
|---|---|
| **A · Entity & Trust Onboarding Wizard** | 3-step wizard (Trust Details / Beneficiaries / Assets & Review) with animated step chips + `AnimatePresence` step transitions. Hand-crafted **720×260 SVG node-tree** rendering `[Non-Grantor Irrevocable Spendthrift Trust]` root → dashed ownership paths (with arrow markers + "owns" pill labels) → `[Whole-Life MEC Policy]` + `[Operating LLC]`. Live `.gan-fluid-cards` summary panel emits 4 config cards. |
| **B · Smart Income & Tax Routing Ledger** | 4 KPI tiles (Form 1041 / Form 1040 / Deferred / Total). Double-entry table opting into `.gan-table-responsive` with `data-label` on 6 columns (Date · Source · Kind · Amount · Tax Route · Note). Deferral toggle + 1/3/5-year horizon buttons. Capital-retention projection card computes `retentionProjection(baseYearly, apr, years, deferred)` — 32% tax drag when non-deferred. |
| **C · Policy Cash Value & Dividend Dashboard** | 4 metric cards (Cash Value $612,400 · Cumulative Dividends $184,700 · LTV Limit 92% · Death Benefit $4,200,000). Hand-crafted **720×200 SVG compound growth curve** — reverse-projects principal from `yearsFunded=9` back to Y0 then forward-projects across `targetYears=25`. Renders 5 gridlines, 3 Y-axis labels, `pathD` line + `areaD` gradient fill, milestone markers at Y5/10/15/20/25, and a special "NOW" vertical marker at Y9. |
| **D · "Borrow & Reinvest" Execution Engine** | Primary CTA card → framer-motion modal with scrim + sheet, `.gan-drawer-mobile` (bottom-sheet on <640px), `role="dialog"`, `aria-modal="true"`, `aria-labelledby="deploy-modal-title"`. Loan-amount input with LTV validation, 4 asset-target buttons (crypto · real-estate · equities · business) with per-asset yield APR. **Live net-yield indicator** — `useMemo` derives `netYieldPct = assetYieldPct + POLICY.dividendApr*100 − POLICY.loanRateApr*100` (principal keeps compounding in policy while loan is active — the Infinite Banking thesis). Execute button simulates 700ms settlement and emits a `lastDeploy` receipt card. |

**Design-system conformance:**
- **CSS Layer 43 tokens** — file consumes `.gan-glass · .gan-card-stack · .gan-fluid-cards · .gan-table-responsive · .gan-drawer-mobile` directly (no bypass, no re-implementation).
- **Touch targets** — every button, input, chip, close-affordance, and modal control has `minHeight: 44` + `minWidth: 44` where applicable + `WebkitTapHighlightColor: 'transparent'` + descriptive `aria-label`.
- **<640px gracefulness** — table opts into card-stack via `.gan-table-responsive`, modal collapses to fixed-bottom sheet via `.gan-drawer-mobile`, KPI clusters use `.gan-fluid-cards`.

**Wire-up ledger:**
| File | Change |
|---|---|
| `src/routes/Module27FamilyBank.tsx` | **NEW** — 1,259 lines, all four widgets + `TrustNodeTree` SVG + `PolicyGrowthCurve` SVG + `ToggleChip` + `SummaryCard` + `S` styles object (mirrors M22 pattern). |
| `src/lib/analytics.ts` | Extended `EventName` union with 7 new events: `module27_view · module27_wizard_step · module27_wizard_complete · module27_deferral_toggled · module27_horizon_selected · module27_deploy_modal_open · module27_deploy_execute`. |
| `src/App.tsx` | Added `lazy(() => import('./routes/Module27FamilyBank'))` + `<Route path="/module/27-family-bank" ...>` block mirroring M22/M25 registration. |
| `src/components/ModulesGrid.tsx` | Inserted M27 registry entry (`code: 'M27' · label: 'Family Bank' · sub: 'Trust · MEC · Policy Loan' · accent: A.emerald · icon: '⚸'`) between M25 and the Trinity section header — Real Estate OS dashboard now surfaces M27 in the 36-destination grid. |
| `src/components/SEO.tsx` | Added `/module/27-family-bank` entry to `ROUTE_META` catalog with **FinancialProduct** JSON-LD schema (name, provider, description, `feesAndCommissionsSpecification: 'Policy loan APR: 5.5% · Dividend APR: 4.8% · LTV: up to 92%'`). |

**Verification (v5.2.3-alpha):**

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ **0 errors** (29.5s) |
| `npm run build` | ✅ Clean — built in **8.12s** — M27 bundle **35.59 kB (9.17 kB gzip)** |
| `curl /module/27-family-bank` | ✅ **HTTP 200** — 6360 bytes, 28ms |
| PM2 `webapp` | ✅ online — serving v5.2.3-alpha |

**Cross-module reuse (extending M08 / M03 / M22 per directive):**
- **Trust-owned MEC policy** slots underneath M08 Fintech's escrow rails (a policy loan settles via the same stablecoin escrow the M08 spec exposes).
- **Form 1041 vs 1040 routing** slots underneath M03 Ledger's double-entry chart-of-accounts (M27 tags each ledger row with the target tax form).
- **DLT cap-table sync** badge on M27 header signals interop with M22 Fractional Ownership's cap-table registry — MEC-policy loan disbursements can hydrate directly into a fractional-STO offering.

### v5.2.2-alpha — Ganymede v2026.1 · Mobile-first audit + JSON-LD SEO + scroll-shadow tables

Applied per user directive: *"Complete all pending tasks, confirm that all mobile first features are correctly configured ESTATE OS™ (v2026.1 Ganymede) … Execute an immediate, systematic audit of the entire codebase (/home/user/webapp/) to guarantee strict adherence to mobile-first standards across every single page, dashboard, content block, table, and module."*

**Strategy: universal CSS layer + surgical per-table opt-in + non-invasive SEO component.** Instead of refactoring 24 module files (regression risk), Ganymede lands as (a) a single **CSS Layer 43** appended to `global.css` that enforces 44×44 touch targets, tap-highlight suppression, safe-area insets, gradient scroll-shadow indicators, and card-stack conversion below 640px — and (b) a **`<Seo />` component** wired above `<Routes>` in `App.tsx` that emits per-route canonical + og + twitter + JSON-LD (RealEstateAgent · FinancialProduct · Product · Service · WebPage · Organization · SoftwareApplication) with zero application-code changes. Only 3 headline tables (M08 Fintech · M22 Cap-Table · M06 Property Ops) plus 2 supporting tables (M03 Portal Grid · M12 Agent Roster) were surgically opted-in with `data-label` attrs so their mobile card-stack rows display their column labels.

| File | Change |
|---|---|
| `src/components/SEO.tsx` | **NEW · 327 lines** — Per-route programmatic SEO. Route catalog covers `/`, `/realestate-os`, `/predictive-os`, `/module/08-fintech`, `/module/22-fractional-ownership`, `/module/06-property-ops`, `/module/05-deal-room`, `/module/11-compliance`, `/estate-brain`, `/reos`. Emits WebPage + Organization + SoftwareApplication + RealEstateAgent + FinancialProduct + Product + Service schemas. Idempotent — all injected tags carry `data-seo="ganymede"` and are cleared/reinjected on route change. |
| `src/App.tsx` | +4 lines — `import Seo` + `<Seo />` mounted above `<Routes>` inside `<SovereignMotionProvider>`. |
| `src/styles/global.css` | **+248 lines · LAYER 43** — Ganymede v2026.1 mobile-first audit layer (details below). |
| `src/routes/Module08Fintech.tsx` | Lender API grid: `.gan-card-stack` class on scroll wrapper + `data-label` on 6 columns (Lender/Region/LTV/Rate/SLA/Action) + button `aria-label` + `minHeight: 44, minWidth: 88, WebkitTapHighlightColor: 'transparent'` on Check button. |
| `src/routes/Module22FractionalOwnership.tsx` | DLT Cap-Table Ledger: `.gan-card-stack` + `data-label` on 5 columns (Wallet/Label/Shares/Allocation/Dividend). Head row marked `.gan-head` so it hides on mobile. |
| `src/routes/Module06PropertyOps.tsx` | Predictive Maintenance table: `.gan-table-responsive` wrapper class + `data-label` on 5 columns (Asset/Component/MTBF/Health/Next Service). |
| `src/routes/Module03InventoryLaunch.tsx` | Portal Distribution table: `.gan-table-responsive` + `data-label` on 6 columns (Portal/Region/Sync latency/Listings/Status/Action). |
| `src/routes/Module12Brokerage.tsx` | Agent Roster table: `.gan-table-responsive` + `data-label` on 7 columns (Agent/Region/Tier/Deals YTD/GCI YTD/Conversion/Action). |

**CSS Layer 43 · Ganymede v2026.1 additions:**

| Feature | Implementation |
|---|---|
| **Universal tap-highlight** | `button, a, [role="button"|link"], input, select, textarea, label, [tabindex]:not([tabindex="-1"]) { -webkit-tap-highlight-color: transparent; touch-action: manipulation; }` — global, no opt-in required. |
| **44×44 touch target enforcement** | `@media (pointer: coarse), (max-width: 900px)` applies `min-height: 44px; min-width: 44px` to all interactive elements (buttons, submit/reset inputs, `role="button"`, `.gan-touch`, `[data-gan-touch]`). Opt-out via `.no-mh` class for icon-only glyphs. |
| **Gradient scroll-shadow on `.v5-scroll-x`** | Roman Komarov's `background-attachment: local` technique — 4 layered gradients (cover-mask + telemetry cyan `#38BDF8` + liquidity emerald `#10B981` shadow radials) that auto-hide when content doesn't overflow. Zero JS. Zero paint cost when idle. Custom `::-webkit-scrollbar` at 6px height with cyan/emerald gradient thumb. |
| **`.gan-card-stack`** | `@media (max-width: 640px)` on `.gan-card-stack > *` — forces `grid-template-columns: 1fr`, converts each row into a stacked card, hides rows with `[data-role="head"]` or `.gan-head`, and injects each `<span>`'s `data-label` attr as an uppercase JetBrains Mono eyebrow via `::before`. |
| **`.gan-table-responsive`** | Same technique for HTML `<table>` — under 640px each `<tr>` becomes a card, `<thead>` is offscreen-positioned, each `<td>` displays its `data-label` prefix. Applied to M03, M06, M12 tables. |
| **Bottom-sheet drawer** | `.gan-drawer-mobile` under 640px pins to bottom, 90vh max, 20px top-corners, safe-area padding, 260ms cubic-bezier animation. Same treatment applied to `.cmdk-panel` (⌘K Command Palette) with a 44×4 drag-handle affordance. |
| **Safe-area vars** | `--gan-safe-top/bottom/left/right` from `env(safe-area-inset-*)` + `.gan-safe-top/-bottom/-x` utility classes for iOS notch / Android gesture bar. |
| **`.gan-glass`** | Spatial glassmorphism preset — `backdrop-filter: blur(24px) saturate(140%)` + linear-gradient depth + inset white 6% highlight + `0 20px 40px -20px` slate-900 drop shadow. |
| **`.gan-fluid-cards`** | `grid-template-columns: repeat(auto-fill, minmax(min(100%, 260px), 1fr))` — fluid card grid that never overflows on narrow viewports. |
| **Overflow bleed guard** | `html, body { overflow-x: hidden; max-width: 100vw; }` — prevents horizontal scroll bleed on mobile from any child element. |

**SEO route catalog (per-route JSON-LD):**

| Route | Schema types |
|---|---|
| `/` | `Organization` + `SoftwareApplication` (BusinessApplication, AggregateRating) |
| `/realestate-os` | `RealEstateAgent` (Global 84 Jurisdictions, `priceRange: $$$`) |
| `/predictive-os` | `Product` (PropTech · SaaS, brand: ESTATE OS™) |
| `/module/08-fintech` | `FinancialProduct` (feesAndCommissionsSpecification: fiat $10 + 45bps · stablecoin $2 + 12bps) |
| `/module/22-fractional-ownership` | `FinancialProduct` (DLT Cap-Table · quarterly dividend automation) |
| `/module/06-property-ops` | `Service` (Predictive Maintenance · SLA Escrow) |
| `/module/05-deal-room`, `/module/11-compliance`, `/estate-brain`, `/reos` | `WebPage` (base) |
| (all routes) | `WebPage` + auto-derived `<title>`, `<link rel=canonical>`, `og:*`, `twitter:*` |

**Verification (v5.2.2-alpha):**

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ **0 errors** (33.9s) |
| `npm run build` | ✅ **22.48s** — Fintech 13.9kB (gzip 4.49) · FracOwn 8.44kB · PropertyOps 14.4kB · Inventory 14.3kB · Brokerage 14.5kB · index 204kB (gzip 59.3) |
| curl smoke — 10 routes | ✅ **10/10 HTTP 200** (`/`, `/realestate-os`, `/predictive-os`, `/module/08-fintech`, `/module/22-fractional-ownership`, `/module/06-property-ops`, `/module/03-inventory-launch`, `/module/12-brokerage`, `/estate-brain`, `/reos`) |
| PM2 `webapp` | ✅ online — serving v5.2.2-alpha commit `9e15a37` |
| Git | ✅ Committed as **`9e15a37`** (rebased from auto-backup) — 8 files, +635/-38 |

**Design principles applied:**
1. **Zero-drift additive**: no existing tokens renamed, no components rewritten. New `<Seo />` component and new CSS layer both purely additive.
2. **Progressive enhancement**: modules that don't opt into `.gan-card-stack` / `.gan-table-responsive` still get the base `v5-scroll-x` horizontal scroll + scroll-shadow indicators — no regression.
3. **Zero-JS overhead for CSS features**: 44px touch, tap-highlight, scroll-shadow, card-stack, and bottom-sheet are all pure CSS. No new JS on the critical path.
4. **A11y-forward**: `role="link"` on ActionStreamCards (inherited from v5.2.1), `aria-label` on Check-lender button, `data-label` provides accessible column context for card-stacked rows.

### v5.2.1-alpha — RealEstateOS ↔ Modules deep-linking + PredictiveLifeOS mobile-first refinement + shared ModulesGrid

Applied per user directive: *"Audit the entire app pages, dashboards etc … update the real estate os based on the modules information and ensure it links directly to all relevant sections/pages/modules/dashboard/etc. Ensure PredictiveLifeOS.tsx is configured to use mobile first features. And proactively complete all pending tasks and deploy through any cloudflare account with required token."*

**Strategy: single shared component, minimal per-page rewrites.** A new `ModulesGrid` component drops into any page and renders the full ESTATE OS™ ecosystem (36 cards across 3 categories) as a mobile-first responsive grid — from 2 cols on phones up to 5 cols on wide desktops. Both `/realestate-os` and `/predictive-os` now embed it in cinematic accent-tinted wrappers so users can jump straight from any dashboard to any module.

| File | Change |
|---|---|
| `src/components/ModulesGrid.tsx` | **New** (523 lines) — Curated registry of 36 destinations across 3 categories (6 dashboards · 24 numbered modules M02–M25 · 6 Trinity suites). Every card renders with an accent glow, category chip, emoji glyph, code (M03, M08…), label, sub-line. **Fully mobile-first**: internal `useBP()` matchMedia hook drives 2/3/4/5-column layout at 560/900/1200 breakpoints, tighter padding + smaller icons on `xs`, `min-height 44px` touch targets, `-webkit-tap-highlight-color: transparent`, `motion.button` with `whileTap: scale 0.96` + `whileHover: y -3px` (desktop only), `initial → animate` staggered fade-up (delay clamped at 0.35s), respects `prefers-reduced-motion`. Props: `filter?` (categories subset), `heading?`, `subtitle?`, `accent?` (drives section-dot glow), `featuredOnly?`, `onNavigate?`, `compact?`. `MODULES_REGISTRY` is exported so callers can inspect it. |
| `src/routes/RealEstateOS.tsx` | **Actions → Modules deep-linking + ecosystem grid.** Added `useNavigate` from react-router. `ActionCard` interface extended with `route: string` field. All 8 `ACTION_CARDS` mapped to owning modules — Counter-offer expiring → `/module/05-deal-room` · Compliance breach → `/module/11-compliance` · Lease renewal → `/module/06-property-ops` · Maintenance emergency → `/module/13-facilities-vendor` · Hot lead → `/module/04-crm-pipeline` · Rent collection → `/module/08-fintech` · Portfolio health → `/module/21-portfolio-reporting` · Market intelligence → `/ai-core`. `ActionStreamCard` gains a `goToModule()` navigator invoked by both the whole card and the CTA button; card is now `role="link"` + `tabIndex={0}` + `Enter/Space` keyboard support. CTA button shows `IcoArrowR` and `Opening…` state after tap. New `ModulesGrid` panel inserted in `DashboardView` between analytics panels and Daily Action Stream — 36 cards under heading *"Explore the ESTATE OS™ ecosystem"* wrapped in a violet-tinted glass panel. |
| `src/routes/PredictiveLifeOS.tsx` | **Mobile-first responsive fixes + bottom ecosystem grid.** Added `useMobileBP()` internal hook returning `xs/sm/lg` tiers driven by resize listener. Component derives `isMobile` (≤1024) + `isXS` (≤560). **Fixed a latent bug**: the split-2 grid `className="v5-split-2"` had `gridTemplateColumns: '1fr'` in its inline style, which — because inline styles beat class rules regardless of `!important` — meant the desktop `.v5-split-2 { grid-template-columns: 1fr 1fr }` rule NEVER won and the layout stayed single-column on desktop. Replaced with matchMedia-driven inline `gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr'`. Persona chip touch target enlarged from 8px→10px padding + `minHeight: 40px` + `WebkitTapHighlightColor: 'transparent'`. Encyclopedia indexChip touch target enlarged from 6px→9px padding + `minHeight: 38px`. Section spacing adapted with `isXS` (12px vs 16px). New `ModulesGrid` panel added above the footer stamp, wrapped in a persona-accent-tinted panel with subtitle *"Continue your learning across the ecosystem"*. |
| `README.md` | v5.2.1-alpha section (this) with per-file ledger, action-to-route mapping table, mobile-first verification notes. |

**Action → Module route map (RealEstateOS dashboard):**

| # | Action card                       | Urgency  | Route                              |
|---|-----------------------------------|----------|------------------------------------|
| 1 | Counter-offer expiring            | critical | `/module/05-deal-room`             |
| 2 | Compliance breach alert           | critical | `/module/11-compliance`            |
| 3 | Lease renewal — tenant response   | high     | `/module/06-property-ops`          |
| 4 | Maintenance emergency             | high     | `/module/13-facilities-vendor`     |
| 5 | New qualified lead — hot buyer    | medium   | `/module/04-crm-pipeline`          |
| 6 | Rent collection — 3 arrears       | medium   | `/module/08-fintech`               |
| 7 | Portfolio health score improved   | low      | `/module/21-portfolio-reporting`   |
| 8 | New market intelligence           | low      | `/ai-core`                         |

**Verification (this turn):**

- `npx tsc --noEmit` → **0 errors** (also fixed 15 lines of corrupted trailing content at the bottom of `RealEstateOS.tsx` that broke the initial typecheck; file now cleanly ends at 2804 lines).
- `npm run build` → **15.77s success**. `RealEstateOS-BH5I8V0h.js` 69.35 kB (gzip 17.07 kB, +1 kB from ecosystem grid) · `PredictiveLifeOS-Ce_Z4I8p.js` 92.67 kB (gzip 25.76 kB, +0.9 kB) · new `index-rLPoqRCc.js` 197.60 kB (gzip 56.77 kB).
- PM2 restart → `HTTP 200` on `/`, `/realestate-os`, `/predictive-os`, `/module/08-fintech`, `/module/05-deal-room`, `/module/11-compliance`, `/estate-brain`, `/reos` (8/8 green).
- Playwright → **0 console errors** on `/realestate-os` (7.22s load) and `/predictive-os` (7.64s load, URL correctly redirected to `?persona=landlord&entry=own`).

### v5.2.0-alpha — Universal Global Navigation + Persona-Based Auth across the entire app

Applied per user directive: *"Audit the entire app pages, dashboards etc… refine the entire app with mobile first features with excellent navigation routes in every click on the header of every page across the entire modules/app. A user can go back or navigate to the next page. Implement Authorization sign in and sign out based on every persona. This should be presented using next generation design to make it easy and fit global standards."*

**Strategy: universal overlay** — instead of rewriting 40+ module files, one navigation layer slots in at the App.tsx root and covers every route in a single pass. Zero per-page changes.

| File | Change |
|---|---|
| `src/lib/auth.ts` | **New** (260 lines) — Persona-based auth store. 7 personas (`landlord`, `tenant`, `agent`, `investor`, `vc`, `pm`, `broker`), each with `icon`, `accent` (hex), `tagline`, `homeRoute` (deep-link on sign-in) and `scopes`. `AuthSession` interface tracks `personaId`, `email`, `displayName`, `signedInAt`, `method` (passcode/passkey/sso/demo), `avatarHue`. Persisted to `localStorage['et_auth_v1']`; cross-tab sync via `storage` event; intra-tab bus via `window.dispatchEvent(new CustomEvent('et:auth-changed'))`. Exports `signIn()`, `signOut()`, `updateDisplayName()`, `getCurrentSession()`, `getPersona()` + React hook `useAuth()` returning `{ session, persona, isSignedIn, signIn, signOut }`. Helpers: `initialsOf()`, `timeAgo()`, internal `hashHue()` for deterministic per-user avatar tint. Isolated from existing `useRole()` (`sessionStorage['et_role']`) — different storage keys, no conflict. |
| `src/components/globalNav/RouteMap.ts` | **New** (209 lines) — Curated 40+ route registry. `RouteEntry` = `{ path, label, short?, category, icon (emoji), keywords, personas?, synopsis? }`; 6 categories (`core`, `dashboard`, `module`, `trinity`, `reos`, `system`). Covers 5 core (Home, AppDemo, Predictive, RealEstateOS, GlobalDominance), 7 dashboards (EstateBrain, EstateOS, AiCore, Fleet, Strategy, Portfolio, Investor), 6 trinity apps (Trinity, Construct, Market, Capital, Reach, Project), 6 REOS routes, 24 numbered modules (M02–M25). Exports `searchRoutes(query, opts)` — weighted fuzzy search across `label`/`short`/`keywords`/`synopsis` returning scored+sorted matches; `findRoute(pathname)` for exact/prefix lookup; `CATEGORY_META` with `label`/`icon`/`accent` per category (drives drawer grouping). |
| `src/components/globalNav/PersonaAuthPanel.tsx` | **New** (437 lines) — Full-screen sign-in/sign-out modal. Reuses `AuroraBackdrop` + `GridCanvas` + `ShimmerText` from `reosFx.tsx` for cinematic identity. Signed-in surface: conic-gradient avatar (`avatarHue`) + display name + email + `timeAgo(signedInAt)` + big **Sign out** button. Signed-out surface: 7 persona cards in `grid-template-columns: repeat(auto-fill, minmax(200px, 1fr))` with `layoutId="auth-persona-tick"` shared-element tick that springs between selection; optional display-name + email fields; method chips (🔐 Passkey · 🏢 SSO · ⌨ Passcode · Continue as demo). 350ms tactile delay on `handleSignIn()` then `navigate(persona.homeRoute)`. Escape-to-close, body-scroll-lock, backdrop click-close. |
| `src/components/globalNav/GlobalNavBar.tsx` | **New** (826 lines) — **Universal top nav on every route.** Layout: [◀ back] [▶ forward · desktop only] [🏠 home] [BrandMark + breadcrumb] · [🔍 search input · desktop] · [🔍 icon · mobile] · [PersonaBadge] · [☰ hamburger · mobile]. `PersonaBadge` shows "Sign in" when signed-out; avatar + short label + name when signed-in. `SearchOverlay` — full-screen modal with input + ↑↓/Enter/Esc keyboard nav, uses `searchRoutes()`; opens on `⌘K` / `Ctrl+K`. `NavDrawer` — right-side spring slide-in (stiffness 320, damping 34) grouping routes by `CATEGORY_META`; ★ tag on `persona.scopes` matches. Exports `shouldHideGlobalNav(pathname)` — returns `true` for `/reos/*` (ReosShell has its own top bar). Additionally suppresses render on `/` while `window.scrollY <= 24` (marketing `<Nav />` leads unmuted at top-of-page). Cross-component event listeners: `etg:open-drawer`, `etg:open-search`, `etg:open-auth` — fired by `MobileBottomNav`. Scoped `.etg-*` CSS with `--etg-h: 58px` + `env(safe-area-inset-top)`, media queries at 900/560/419px, `prefers-reduced-motion` respected. |
| `src/components/globalNav/MobileBottomNav.tsx` | **New** (295 lines) — Fixed bottom tab bar, mobile-only (`≤ 899px` via `matchMedia`). 5 tabs: [🏠 Home → `navigate('/')`] [◫ Modules → `emit('etg:open-drawer')`] [🔍 Search → `emit('etg:open-search')`] [👤 Account → `emit('etg:open-auth')`, avatar swap when signed-in] [☰ More → drawer]. `layoutId="etg-mobile-tab"` shared-element underline (`linear-gradient(90deg, #7dd3fc, #a78bfa, #f472b6)`) springs between tabs. Same suppression as GlobalNavBar: hides on `/reos/*` (ReosShell owns its bottom nav) and on `/` at top scroll. `62px` height + `env(safe-area-inset-bottom)`. Spacer div prevents content occlusion. |
| `src/App.tsx` | **Wired** — added `import GlobalNavBar from './components/globalNav/GlobalNavBar'` + `import MobileBottomNav from './components/globalNav/MobileBottomNav'`. Rendered right after existing `<Nav />` (line ~601), before `<CommandPalette />`. Existing `<Nav />` retained — it leads on `/` while at top-scroll; GlobalNavBar takes over below scroll 24 and on all non-marketing routes. No route removals or reorderings. |

**Coordination map** (no double-bar collisions):

| Route pattern | Top bar | Bottom bar |
|---|---|---|
| `/` (scroll ≤ 24) | `<Nav />` (marketing) only | *(none)* |
| `/` (scroll > 24) | `<Nav />` + `GlobalNavBar` (GlobalNavBar shows) | `MobileBottomNav` (mobile) |
| `/reos/*` | `ReosShell` own top bar only | `ReosShell` own bottom tab bar only |
| Everything else (40+ routes) | `<Nav />` + `GlobalNavBar` | `MobileBottomNav` (mobile) |

**Verification (this turn):**

- `npx tsc --noEmit` → **0 errors** across 5 new/edited files (only patch needed: `import GlobalNavBar from ...` default-import, not named).
- `npm run build` → **7.89s success**, all chunks emit, `etg-nav` + `etg-mbn` classes verified present in `dist/assets/index-DMzzZ-Ag.js`.
- PM2 restart → `webapp` online, `HTTP 200` on `/`, `/realestate-os`, `/predictive-os`, `/app/demo`, `/module/08-fintech`, `/estate-brain`, `/trinity`, `/fleet`, `/reos`, `/reos/ledger`, `/global-dominance`, `/portfolio` (12/12 routes green).
- Playwright console capture → **0 console errors**, 0 page errors on `/realestate-os` (page load timeout was due to continuous framer-motion aurora animations preventing `networkidle`; curl-verified 200 in 76ms via sandbox tunnel and full HTML shell serves correctly).

### v5.1.0-alpha.hotfix — Mobile-first refactor + next-generation cinematic design pass
Applied per user directive: *"mobile first features · global grade through design and next generation features to make every user to stick to the app from the first click · powerful animation, graphics, etc."* Scope: entire `/reos/*` sub-app.

| File | Change |
|---|---|
| `src/lib/reosFx.tsx` | **New** — 8 next-gen design primitives + global style module. `AuroraBackdrop` (drifting radial gradients + SVG turbulence noise), `GridCanvas` (48px grid + radial mask fade), `CountUp` (`useMotionValue` + `useSpring` animated numbers), `Reveal` (fade-up cinematic entrance with stagger delay), `ShimmerText` (animated `background-clip: text` shimmer), `PulseDot` (dot + expanding ring), `TapCard` (`motion.button` tactile press with `whileTap` / `whileHover`), `Marquee` (double-render infinite horizontal scroll with edge mask). `ReosGlobalStyle` sets `:focus-visible`, `::selection`, `@media (prefers-reduced-motion: reduce)` overrides + safe-area CSS vars. Every primitive respects `useReducedMotion()`. |
| `src/components/reos/ReosShell.tsx` | **Rewritten** — mobile-first shell. Adds `isMobile` to `ReosContext` (window `< 900px` + resize listener). New: **hamburger drawer** (slide-in from left with spring + backdrop blur + body-overflow lock + safe-area padding), **bottom-tab bar** (6-tab grid, `layoutId="reos-tab-active"` spring-animated underline between active tabs), **sticky switcher strip** with horizontal-scroll snap on mobile, `env(safe-area-inset-*)` for iPhone notch/home-indicator. Sidebar hidden below 900px. |
| `src/routes/reos/CommandCenter.tsx` | **Rewritten** — cinematic hero: `AuroraBackdrop` + `GridCanvas` + `ShimmerText` headline + staggered `Reveal` chips + `PulseDot` live status. KpiCards with `CountUp` animated numbers + ambient blur-glow corner motion. MarginGauge (176px SVG) with spring `strokeDashoffset` + `drop-shadow`. WorldCanvas with radial-gradient continent fill + **animated quadratic-bezier arcs** (`pathLength: 0→1`) connecting property pins. FxTicker uses grid on desktop, `Marquee` scroll on mobile (<560px). EventCards with moving highlight sweep. NextStepStrip via `TapCard`. |
| `src/routes/reos/LedgerInspector.tsx` | **Rewritten** — mobile-first. Cinematic Hero (`AuroraBackdrop` + `ShimmerText` + `PulseDot` book-health status + `CountUp` event/posting counters). **Sticky mode-tab bar** with horizontal-scroll snap + `layoutId="reos-mode-underline"` spring underline. SIDE_BY_SIDE auto-collapses to IFRS on mobile. Trial-balance rows: **desktop table** (with per-row fade-up stagger) + **mobile card fallback below 560px** (grid layout with debit/credit/net stacked). EventList: sticky search header + `PulseDot` count badge + 64px min touch target rows with `whileTap` scale + momentum scroll. EventDrilldown: collapsible JSON accordion (default-closed on mobile), postings as cards below 560px. ExportStrip: `TapCard` tactile buttons + horizontal-scroll on mobile with short labels. |
| `src/routes/reos/S2Stub.tsx` | **Rewritten** — Session-2 stubs (`/reos/compliance`, `/reos/escrow`, `/reos/title`, `/reos/sovereign`) upgraded to the cinematic design language. `AuroraBackdrop` + `GridCanvas` + `ShimmerText` title + staggered `Reveal` on invariants and screens. CTAs use `TapCard` with 44px min touch target. |
| `README.md` | v5.1.0-alpha.hotfix section (this) |

**Mobile-first patterns applied:**
- 📱 Bottom-tab bar (6 tabs) with `layoutId` spring underline · slide-in drawer with backdrop blur · sticky switcher strip with scroll-snap · safe-area insets for iPhone notch/home-indicator
- 📐 Fluid typography (`clamp(22px, 5.4vw, 34px)`) · media queries at 1100 / 900 / 620 / 560 / 419px · min 44px touch targets everywhere
- 🎯 Trial-balance table → card grid below 560px (grid `1fr auto` with DR/CR/Net stacked) · postings table → card list · export buttons → horizontal-scroll with abbreviated labels
- 🔒 Global `-webkit-tap-highlight-color: transparent` · `:focus-visible` outline · `-webkit-overflow-scrolling: touch` on all scrollable regions

**Next-generation design features:**
- 🌌 Aurora backdrops (layered radial gradients drifting on a slow spring loop + SVG turbulence noise texture)
- ✨ Shimmer headline text with animated `background-clip: text` gradient sweep
- 🔢 CountUp animated KPI numbers via `useSpring`
- 🌊 Staggered `Reveal` cinematic fade-ups across every screen
- 💫 Pulsing status dots with expanding-ring rims
- 🎬 Moving highlight sweep on event cards (`x: -100% → 100%` linear infinite, randomized start)
- 🌐 Animated quadratic-bezier arcs connecting property pins on the world canvas
- 🎢 Marquee FX ticker (double-render infinite linear scroll with edge mask) on mobile
- 🖱 `TapCard` tactile press (`whileTap: scale(0.98)` + `whileHover: y=-1`) on every actionable card
- ♿ `useReducedMotion()` respect on every animated primitive — instant static rendering when the user opts out at OS level

**Verification:** `npx tsc --noEmit` **0 errors** · `npm run build` **7.57s** (LedgerInspector 28.01 kB, ReosShell 33.24 kB, CommandCenter 19.65 kB) · **7/7 REOS routes HTTP 200** · Playwright console capture on `/reos` + `/reos/ledger` → **0 messages, 0 errors** · page titles resolve correctly.

### v5.1.0-alpha — Tenancy OS REOS Core Engine · Event-Sourced Multi-GAAP Ledger
Session 1 of the ADR-approved Global REOS refactor. Ships the entire engine layer plus 2 of 6 core-engine screens; the 4 remaining screens are wired as roadmap stubs.

| File | Change |
|---|---|
| `src/lib/reos/types.ts` | **New** — full type contract: `LedgerEvent`, `JournalPosting`, `Property`, `FxRate`, `TrialBalance`, `KpiSnapshot`, `LedgerImbalanceException`, `FiduciaryViolationException`. Chart of accounts (`ACCOUNTS`) with `is_fiduciary` flag on trust accounts. **All money = integer `Cents`** (never Number). |
| `src/lib/reos/ledger/engine.ts` | **New** — pure `buildEmit(input, sequence)` deriving balanced postings across `US_GAAP`, `IFRS`, `LOCAL_STATUTORY`. Enforces fiduciary-account guard. Applies FX to every leg. |
| `src/lib/reos/ledger/postingRules.ts` | **New** — 10 event types × 3 books = deterministic debit/credit legs. `US_GAAP`/`IFRS` accrue rent on invoice; `LOCAL_STATUTORY` cash-basis; `IFRS` nets CAM/NNN recovery. |
| `src/lib/reos/ledger/fx.ts` | **New** — deterministic 6-month FX curve for EUR/BRL/SGD/GBP, `rateAt(currency, date)` interpolation, `toReportingCents()` USD conversion, `fxDelta30d()` for ticker. |
| `src/lib/reos/ledger/auditor.ts` | **New** — `assertBalanced()` throws `LedgerImbalanceException` if Σdebit ≠ Σcredit per book per event. `computeTrialBalance(book)` builds full trial balance in USD reporting. |
| `src/lib/reos/store.ts` | **New** — D1-shaped `LedgerStore` interface + in-memory singleton. `append()` / `events()` / `postings()` / `trialBalance()` / `kpis()` / `subscribe()`. `ensureSeeded()` lazily replays 6-month history on first mount. |
| `src/lib/reos/seed/properties.ts` | **New** — 5 properties: NYC (multifamily, USD), Berlin (multifamily, EUR), Paris (retail, EUR), São Paulo (industrial, BRL), Singapore (retail, SGD). Includes `mapX/mapY` for stylized world canvas + `registryAdapter` picker. |
| `src/lib/reos/seed/replay.ts` | **New** — deterministic mulberry32 replay — one deposit + monthly rent-charged/collected + maintenance/utilities/tax/insurance + quarterly CAM (retail/industrial) + FX revaluation. ~300 events on boot. |
| `src/lib/reos/index.ts` | **New** — engine facade / barrel. |
| `src/lib/reosTokens.ts` | **New** — dark-enterprise palette (`#0f172a` Navy · `#1e293b` Slate · `#10b981` Emerald · `#f59e0b` Amber · `#38bdf8` Sky). `reosCard()`, `reosChip()`, `fmtCents()`, `fmtPct()`. |
| `src/components/reos/ReosShell.tsx` | **New** — dedicated `/reos/*` shell with 4 persistent global switchers (Region · Jurisdiction · Asset Class · GAAP Book), sidebar nav to all 6 core routes, live invariant status. `useReosContext()` hook + `tick`-based store subscription. Fully responsive at 900 / 560px. |
| `src/routes/reos/CommandCenter.tsx` | **New (`/reos`)** — Global Executive Command Center. Stylized SVG regional world canvas with pulsing property pins per region; 80%+ gross-margin gauge with SVG stroke-length animation; multi-currency FX ticker with `↑↓` 30-day deltas; USD reporting cash-flow card; live trial-balance health check; recent-events feed; roadmap strip. |
| `src/routes/reos/LedgerInspector.tsx` | **New (`/reos/ledger`)** — Multi-GAAP Ledger Inspector. Four view modes: Side-by-Side / US_GAAP / IFRS / LOCAL_STATUTORY. Full trial balance per book with debit/credit/net columns and per-account kind chips. Event stream browser with search + drill-down. Selected event → raw JSON view + all 3-book derived postings with per-book balance check. **CSV exports**: 3 trial-balance CSVs + events log + full postings log — regulator-ready. |
| `src/routes/reos/S2Stub.tsx` | **New** — Session-2 roadmap stubs for `/reos/compliance`, `/reos/escrow`, `/reos/title`, `/reos/sovereign`. Each shows invariants to enforce + planned screens + ETA. |
| `src/App.tsx` | +6 `React.lazy` REOS imports and +6 `<Route>` entries (`/reos`, `/reos/ledger`, plus 4 stubs). |
| `README.md` | v5.1.0-alpha section (this) |

**Core invariants active today:**
- ✅ Integer-cents precision on every posting (no floats)
- ✅ Double-entry trial balance enforced per event per book (`LedgerImbalanceException`)
- ✅ Fiduciary trust isolation on `DEPOSIT_RECEIVED` / `DEPOSIT_REFUNDED` (`FiduciaryViolationException`)
- ✅ Immutable event log — `Object.freeze()` on every event/posting
- ✅ Deterministic policy: same event stream + same book config → same trial balance

**Verification:** `npx tsc --noEmit` **0 errors** · `npm run build` **OK** (new chunks: ReosShell 20.88 kB, LedgerInspector 16.88 kB, CommandCenter split) · **6/6 REOS routes HTTP 200** · **6 regression routes HTTP 200** · no runtime console errors.

**Next (v5.1.0-beta, Session 2):** Policy-as-Code engine (6 jurisdictions) · Payment rails + fiduciary guard UI · Title registry adapters (Anglo-American REST + Civil-Law XML) · Sovereign data cell (WebCrypto PII masking) · Asset-class micro-plugins · Wire M08/M11/M18 to REOS store.

### v5.0.0-epsilon — AppDemo Sales Engine + Encyclopedia PredictiveOS + Animated Graph Primitives
| File | Change |
|---|---|
| `src/lib/v5Interactions.tsx` | **+6 SVG graph primitives** — `Sparkline`, `AreaChart`, `BarChart`, `Donut`, `Treemap`, `RadialKnowledgeGraph` — all pure SVG + framer-motion (path-length, opacity, spring). Exports: `KGNode`, `KGEdge`, `RadialKnowledgeGraphProps`, etc. |
| `src/lib/analytics.ts` | +9 new `EventName` entries: `appdemo_persona_switched`, `appdemo_module_launch`, `appdemo_cta_click`, `appdemo_upgrade_click`, `predictive_persona_switched`, `predictive_node_clicked`, `predictive_action_launched`, `predictive_cert_started`, `predictive_copilot_prompt` |
| `src/routes/AppDemo.tsx` | **Full rewrite (~48KB)** — 7-persona sales engine dashboard (landlord/tenant/agent/investor/vc/pm/broker). Each persona: hero + Donut, 6 animated KPI cards, AreaChart (revenue), BarChart (cash-flow), AreaChart (occupancy), Treemap (portfolio composition), portfolio table with per-row Sparklines, module launch grid, live activity stream, upgrade CTA. Every click routes via `resolveModuleRoute()` |
| `src/routes/PredictiveLifeOS.tsx` | **Full rewrite (~125KB, 806 lines)** — Encyclopedia-style knowledge graph. 8 personas (landlord/tenant/agent/investor/vc/pm/govt/vendor) × ~12 entries each. Each node = clickable encyclopedia article with 7 fields: definition · why it matters · your current state (metric grid) · solution modules · related concepts · recommended learning · recommended actions. Split layout: radial `RadialKnowledgeGraph` (left) + live article (right), collapses ≤1024px. URL sync `?persona=xxx&entry=yyy`. Priority actions list, learning path (6 certs), badges, AI copilot teaser |
| Mobile responsiveness | `.v5-split-2`, `.v5-cards`, `.v5-kpi-4`, `.v5-scroll-x` classes in `TrinityShell.tsx` with `@media` at 1024/768/420px. Fluid typography `clamp(16px, 3.4vw, 22px)`. Horizontal-scroll encyclopedia index chips |

### v5.0.0-delta — 13 additional ESTATE OS™ modules wired
| File | Change |
|---|---|
| `src/App.tsx` | +13 `React.lazy` imports and 13 `<Route>` entries: M02, M07, M09, M11, M13, M14, M15, M16, M17, M18, M20, M21, M25 |
| `src/components/TrinityShell.tsx` | +13 `TRINITY_LINKS` entries for the new modules (layer/accent/icon/sub) |
| `src/routes/Module02PropertyGraph.tsx` | 4 twin layers · 6 hot-zone pins with animated orbit rings |
| `src/routes/Module07ListingsDistribution.tsx` | 14 portal connectors · category tabs |
| `src/routes/Module09TenantScreening.tsx` | 6 applicants · KYC panel |
| `src/routes/Module11Compliance.tsx` | 8-jurisdiction rule engine · live rule feed |
| `src/routes/Module13FacilitiesVendor.tsx` | Work-order queue · vendor marketplace |
| `src/routes/Module14InsuranceWarranty.tsx` | Policies · claims · parametric triggers |
| `src/routes/Module15ConciergeExperience.tsx` | Services · inbox · NPS |
| `src/routes/Module16CommunityGovernance.tsx` | DAO proposals · treasury |
| `src/routes/Module17EsgCarbonLedger.tsx` | Scope 1/2/3 · certifications |
| `src/routes/Module18DataRoomDiligence.tsx` | Folders · Q&A · activity |
| `src/routes/Module20InsuranceLinkedSecurities.tsx` | Cat bonds · reinsurance |
| `src/routes/Module21PortfolioReporting.tsx` | Funds · benchmarks · LP letters |
| `src/routes/Module25GlobalNomad.tsx` | Countries · passports · housing |

### v5.0.0-gamma — /app/demo + /predictive-os refinement (superseded by epsilon)
Refined initial dashboard scaffolding; superseded by v5-epsilon full rewrite (see above).

### v5.0.0-beta — TrinityShell v5 blueprint + interaction primitives
| File | Change |
|---|---|
| `src/lib/v5Interactions.tsx` | Base primitives: `TiltCard`, `MagneticTile`, `SpotlightCard`, `RippleButton`, `PulseDot`, `StaggerContainer`, `CountUpText`, `useNavigateModule` |
| `src/lib/moduleRoutes.ts` | `MODULE_ROUTES` registry (14 entries), `resolveModuleRoute()` fuzzy tag scoring, `personaToModuleRoute()` |
| `src/components/TrinityShell.tsx` | v5 shell with Crumb component, activePath, glass card styling |

### v5.0.0-alpha — Capital Layer suite
Fund / REIT / LP dashboards, waterfall, NAV widget scaffolding.

### v4.9
| File | Change |
|---|---|
| `src/routes/FleetCore.tsx` | **New** — 1,090-line Robotics Command Center (map + telemetry panel + 4 tabs) |
| `src/lib/fleetData.ts` | **New** — Robots, missions, incidents, care alerts, escorts, deliveries, maintenance scans, protocols + live-tick + KPI aggregator |
| `src/lib/analytics.ts` | +10 new `EventName` entries for fleet interactions |
| `src/App.tsx` | Lazy-imported `FleetCore`; added `/fleet` route + `/robotics` `/fleet-core` redirects |
| `src/components/Nav.tsx` | Added **"Fleet Core"** link (desktop + mobile drawer) |
| `src/routes/EstateBrain.tsx` | Added "Open Fleet Core (robotics)" CTA in final section |
| `README.md` | Updated to v4.9 |

### v4.8 — ESTATE OS™ Module Map
| File | Change |
|---|---|
| `src/routes/EstateBrain.tsx` | New — 25-module map (framer-motion, LayoutGroup, 6 pillars) |
| `src/App.tsx` | Lazy-imported EstateBrain; added `/estate-brain` + `/modules` `/global-os` redirects |
| `src/components/Nav.tsx` | Added "Global OS" link |

---

**Last updated**: 2026-09-06 · **v5.5.1-alpha M1.8 · KES-First Waste Anchor UX + Arithmetic Precision** (M1.5 SDMX→C14N→SHA3-512→Merkle→XRPL pipeline · M1.6 3T+ viewport tokens + `useViewport` hook · M1.7 `/api/anchor` Cloudflare Functions parity with byte-identical dry-run · M1.8 KES-default `/waste-anchor` route with fixed-point `driftSafeSum`, 85% scoped coverage floor, Playwright waste-anchor.spec.ts, `useIsMobile` deprecated. `tsc --noEmit` 0 errors · `vitest run` 229/229 pass across 10 files · `npm run build` clean with lazy `WasteAnchor-*.js` chunk.)

**Previously**: 2026-08-19 · **v5.2.4-alpha · Comprehensive Mobile-First Audit** (PredictiveLifeOS 7 style tokens + 4 CTA sites brought to 44×44 px min with tap-highlight-transparent + touch-action:manipulation · 6 remaining tables opted into `.gan-table-responsive` with 46 `data-label` attrs across AppDemo/GlobalDominance/EasyConstruct/EasyMarket/EasyCapital/EasyReach · reos/LedgerInspector's custom 560 px card fallback correctly preserved · tsc 0 errors 28.7 s · clean build 8.12 s · 9-route curl smoke all HTTP 200 · PredictiveLifeOS bundle +0.57 kB proportional to CSS additions)
